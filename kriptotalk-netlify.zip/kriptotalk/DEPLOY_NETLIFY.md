# 🚀 Cara Deploy KriptoTalk ke Netlify

## Langkah 1 — Upload ke GitHub

Kamu perlu push project ke GitHub dulu agar bisa di-deploy ke Netlify.

```bash
# Di folder kriptotalk/
git init
git add .
git commit -m "KriptoTalk v2 - init"

# Buat repo baru di github.com, lalu:
git remote add origin https://github.com/USERNAME/kriptotalk.git
git push -u origin main
```

---

## Langkah 2 — Deploy ke Netlify

1. Buka [netlify.com](https://netlify.com) → Login
2. Klik **"Add new site" → "Import an existing project"**
3. Pilih **GitHub** → pilih repo `kriptotalk`
4. Netlify akan otomatis detect Next.js
5. Klik **Deploy site**

> Build settings otomatis terbaca dari `netlify.toml`:
> - Build command: `npm run build`
> - Publish directory: `.next`

---

## Langkah 3 — Isi Environment Variables di Netlify

Buka: **Site Settings → Environment Variables → Add variable**

Isi satu per satu:

| Key | Value |
|-----|-------|
| `GOOGLE_CLIENT_ID` | `111427949829-aeu3irpt0mq277kk0g7v3lhdaivbfnrk.apps.googleusercontent.com` |
| `GOOGLE_CLIENT_SECRET` | *(dari Google Console)* |
| `AUTH_SECRET` | *(generate: `openssl rand -base64 32`)* |
| `NEXTAUTH_URL` | `https://nama-site-kamu.netlify.app` |
| `NEXT_PUBLIC_FIREBASE_API_KEY` | *(dari Firebase)* |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | *(dari Firebase)* |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | *(dari Firebase)* |
| `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` | *(dari Firebase)* |
| `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` | *(dari Firebase)* |
| `NEXT_PUBLIC_FIREBASE_APP_ID` | *(dari Firebase)* |
| `NEXT_PUBLIC_EMAILJS_SERVICE_ID` | *(opsional)* |
| `NEXT_PUBLIC_EMAILJS_TEMPLATE_ID` | *(opsional)* |
| `NEXT_PUBLIC_EMAILJS_PUBLIC_KEY` | *(opsional)* |

Setelah isi semua → klik **"Trigger deploy"**

---

## Langkah 4 — Update Google OAuth Callback URL

Setelah dapat URL Netlify (misal `https://kriptotalk.netlify.app`):

1. Buka [console.cloud.google.com](https://console.cloud.google.com)
2. APIs & Services → Credentials → Edit OAuth client
3. **Authorized redirect URIs** → Add:
   ```
   https://kriptotalk.netlify.app/api/auth/callback/google
   ```
4. **Authorized JavaScript origins** → Add:
   ```
   https://kriptotalk.netlify.app
   ```
5. Klik **Save**

---

## Langkah 5 — Update Firebase Authorized Domains

1. Buka Firebase Console → Authentication → Settings
2. **Authorized domains** → Add domain:
   ```
   kriptotalk.netlify.app
   ```

---

## Langkah 6 — Set Password Pertama

1. Buka `https://nama-site-kamu.netlify.app/admin`
2. Login dengan Google (`k.amato.m.b@gmail.com`)
3. Isi password pertama di form
4. Klik **Simpan**

Selesai! Website siap dipakai 🎉

---

## ⚙️ Custom Domain (opsional)

Jika punya domain sendiri:
1. Netlify → Domain settings → Add custom domain
2. Update `NEXTAUTH_URL` ke domain kamu
3. Update Google OAuth callback URL ke domain kamu
4. Update Firebase authorized domain

---

## 🔁 Update Otomatis

Setiap kali kamu `git push` ke GitHub, Netlify akan otomatis build dan deploy ulang.

---

## ❓ Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Login Google gagal / redirect error | Pastikan `NEXTAUTH_URL` sesuai domain Netlify |
| Firebase connection error | Pastikan semua `NEXT_PUBLIC_FIREBASE_*` sudah diisi |
| Build gagal | Cek log build di Netlify → Deploys |
| 404 pada halaman | Pastikan plugin `@netlify/plugin-nextjs` terinstall |
