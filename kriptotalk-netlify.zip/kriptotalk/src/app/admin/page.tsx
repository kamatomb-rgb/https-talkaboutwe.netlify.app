'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSession, signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import {
  Shield, Lock, Key, RefreshCw, Eye, EyeOff,
  CheckCircle, XCircle, Clock, Loader2, LogIn,
  AlertTriangle, Users, Activity, ArrowLeft
} from 'lucide-react'
import {
  getAccessPassword, setAccessPassword, getAccessLogs,
  initDefaultPassword, type AccessLog
} from '@/lib/firebase'
import { cn } from '@/lib/utils'

const ADMIN_EMAIL = 'k.amato.m.b@gmail.com'

export default function AdminPage() {
  const { data: session, status: authStatus } = useSession()
  const router = useRouter()

  const [currentPw, setCurrentPw] = useState<string>('')
  const [newPw, setNewPw] = useState('')
  const [showCurrentPw, setShowCurrentPw] = useState(false)
  const [showNewPw, setShowNewPw] = useState(false)
  const [logs, setLogs] = useState<AccessLog[]>([])
  const [loadingPw, setLoadingPw] = useState(false)
  const [loadingLogs, setLoadingLogs] = useState(false)
  const [savingPw, setSavingPw] = useState(false)
  const [saveMsg, setSaveMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
  const [stats, setStats] = useState({ total: 0, success: 0, failed: 0 })

  const isAdmin = session?.user?.email === ADMIN_EMAIL

  // Load data
  const loadData = useCallback(async () => {
    setLoadingPw(true)
    setLoadingLogs(true)
    try {
      const [pw, logData] = await Promise.all([
        getAccessPassword(),
        getAccessLogs(),
      ])
      setCurrentPw(pw || '(belum ada)')
      setLogs(logData)
      setStats({
        total: logData.length,
        success: logData.filter(l => l.success).length,
        failed: logData.filter(l => !l.success).length,
      })
    } catch (e) {
      console.error(e)
    } finally {
      setLoadingPw(false)
      setLoadingLogs(false)
    }
  }, [])

  useEffect(() => {
    if (isAdmin) loadData()
  }, [isAdmin, loadData])

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newPw.trim() || newPw.length < 4) {
      setSaveMsg({ type: 'error', text: 'Password minimal 4 karakter' })
      return
    }
    setSavingPw(true)
    setSaveMsg(null)
    const ok = await setAccessPassword(newPw.trim())
    if (ok) {
      setSaveMsg({ type: 'success', text: `✅ Password berhasil diubah menjadi: "${newPw.trim()}"` })
      setCurrentPw(newPw.trim())
      setNewPw('')
    } else {
      setSaveMsg({ type: 'error', text: '❌ Gagal simpan. Cek koneksi Firebase.' })
    }
    setSavingPw(false)
    setTimeout(() => setSaveMsg(null), 5000)
  }

  // ── Belum login ──────────────────────────────────────────────
  if (authStatus === 'loading') {
    return (
      <div className="min-h-screen bg-bg-primary flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-accent-primary animate-spin" />
      </div>
    )
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-bg-primary flex items-center justify-center px-6">
        <div className="glass border border-border-primary rounded-2xl p-8 max-w-sm w-full text-center animate-slide-up">
          <Shield className="w-12 h-12 text-accent-primary mx-auto mb-4" strokeWidth={1.5} />
          <h1 className="text-xl font-bold text-text-primary mb-2">Admin KriptoTalk</h1>
          <p className="text-text-muted text-sm mb-6">Login dengan akun Google admin untuk melanjutkan.</p>
          <button
            onClick={() => signIn('google', { callbackUrl: '/admin' })}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm"
            style={{ background: 'linear-gradient(135deg, #0d3464, #1a1a3e)', border: '1px solid #00d4ff33' }}
          >
            <LogIn className="w-4 h-4 text-accent-primary" />
            <span className="text-white">Login dengan Google</span>
          </button>
        </div>
      </div>
    )
  }

  // ── Bukan admin ──────────────────────────────────────────────
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-bg-primary flex items-center justify-center px-6">
        <div className="glass border border-red-500/30 rounded-2xl p-8 max-w-sm w-full text-center animate-slide-up">
          <AlertTriangle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h1 className="text-xl font-bold text-red-400 mb-2">Akses Ditolak</h1>
          <p className="text-text-muted text-sm mb-2">
            Akun <span className="text-text-primary font-mono">{session.user?.email}</span> bukan admin.
          </p>
          <p className="text-text-muted text-xs mb-6">Hanya <span className="text-accent-primary">{ADMIN_EMAIL}</span> yang bisa akses halaman ini.</p>
          <button
            onClick={() => router.push('/chat')}
            className="flex items-center gap-2 mx-auto text-sm text-accent-primary hover:underline"
          >
            <ArrowLeft className="w-4 h-4" />
            Kembali ke Chat
          </button>
        </div>
      </div>
    )
  }

  // ── Admin panel ──────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-bg-primary noise-overlay">
      <div className="absolute inset-0 grid-bg opacity-30" />

      <div className="relative z-10 max-w-3xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Shield className="w-6 h-6 text-accent-primary" />
              <h1 className="text-2xl font-bold gradient-text">Admin Panel</h1>
            </div>
            <p className="text-xs text-text-muted font-mono">
              Login sebagai: <span className="text-accent-primary">{session.user?.email}</span>
            </p>
          </div>
          <button
            onClick={() => router.push('/chat')}
            className="flex items-center gap-1.5 text-sm text-text-muted hover:text-text-secondary transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Kembali
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {[
            { label: 'Total Percobaan', value: stats.total, icon: Activity, color: 'text-accent-primary' },
            { label: 'Berhasil Masuk', value: stats.success, icon: CheckCircle, color: 'text-status-online' },
            { label: 'Gagal / Ditolak', value: stats.failed, icon: XCircle, color: 'text-red-400' },
          ].map(s => (
            <div key={s.label} className="glass border border-border-primary rounded-xl p-4 text-center">
              <s.icon className={`w-5 h-5 ${s.color} mx-auto mb-1.5`} />
              <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-xs text-text-muted mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Password Management */}
        <div className="glass border border-border-primary rounded-2xl p-6 mb-6">
          <div className="flex items-center gap-2 mb-5">
            <Key className="w-5 h-5 text-accent-primary" />
            <h2 className="font-bold text-text-primary">Kelola Kata Kunci Akses</h2>
          </div>

          {/* Current password */}
          <div className="mb-5">
            <label className="block text-xs text-text-muted font-mono mb-2">PASSWORD AKTIF SAAT INI</label>
            <div className="relative">
              <div className="bg-bg-input border border-border-secondary rounded-xl px-4 py-3 font-mono text-sm flex items-center justify-between">
                <span className={`text-text-primary ${!showCurrentPw ? 'blur-sm select-none' : ''} transition-all`}>
                  {loadingPw ? '...' : currentPw}
                </span>
                <button
                  onClick={() => setShowCurrentPw(!showCurrentPw)}
                  className="text-text-muted hover:text-text-secondary ml-3"
                >
                  {showCurrentPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

          {/* Change password form */}
          <form onSubmit={handleChangePassword} className="space-y-3">
            <label className="block text-xs text-text-muted font-mono">PASSWORD BARU</label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type={showNewPw ? 'text' : 'password'}
                  value={newPw}
                  onChange={e => setNewPw(e.target.value)}
                  placeholder="Ketik password baru..."
                  className="w-full bg-bg-input border border-border-secondary rounded-xl px-4 py-3 pr-11 text-sm text-text-primary placeholder-text-muted focus:outline-none focus:border-accent-primary/60 font-mono transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPw(!showNewPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted"
                >
                  {showNewPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <button
                type="submit"
                disabled={!newPw.trim() || savingPw}
                className="px-5 py-3 rounded-xl font-semibold text-sm transition-all disabled:opacity-40 flex items-center gap-2 flex-shrink-0"
                style={{ background: 'linear-gradient(135deg, #0d3464, #1a1a3e)', border: '1px solid #00d4ff33' }}
              >
                {savingPw ? (
                  <Loader2 className="w-4 h-4 animate-spin text-accent-primary" />
                ) : (
                  <Lock className="w-4 h-4 text-accent-primary" />
                )}
                <span className="text-white">Simpan</span>
              </button>
            </div>

            {saveMsg && (
              <div className={cn(
                'flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm animate-fade-in',
                saveMsg.type === 'success'
                  ? 'bg-status-online/10 border border-status-online/20 text-status-online'
                  : 'bg-red-500/10 border border-red-500/20 text-red-300'
              )}>
                {saveMsg.type === 'success'
                  ? <CheckCircle className="w-4 h-4 flex-shrink-0" />
                  : <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                }
                {saveMsg.text}
              </div>
            )}
          </form>
        </div>

        {/* Access Logs */}
        <div className="glass border border-border-primary rounded-2xl p-6">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-accent-primary" />
              <h2 className="font-bold text-text-primary">Log Percobaan Masuk</h2>
            </div>
            <button
              onClick={loadData}
              disabled={loadingLogs}
              className="flex items-center gap-1.5 text-xs text-text-muted hover:text-accent-primary transition-colors"
            >
              <RefreshCw className={cn('w-3.5 h-3.5', loadingLogs && 'animate-spin')} />
              Refresh
            </button>
          </div>

          {loadingLogs ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 text-accent-primary animate-spin" />
            </div>
          ) : logs.length === 0 ? (
            <div className="text-center py-8">
              <Activity className="w-10 h-10 text-text-muted mx-auto mb-2 opacity-40" />
              <p className="text-text-muted text-sm">Belum ada percobaan masuk</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {logs.map((log, i) => (
                <div
                  key={log.id || i}
                  className={cn(
                    'flex items-start gap-3 p-3 rounded-xl border text-sm',
                    log.success
                      ? 'bg-status-online/5 border-status-online/15'
                      : 'bg-red-500/5 border-red-500/15'
                  )}
                >
                  {log.success
                    ? <CheckCircle className="w-4 h-4 text-status-online mt-0.5 flex-shrink-0" />
                    : <XCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                  }
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-0.5">
                      <span className={`font-semibold text-xs ${log.success ? 'text-status-online' : 'text-red-400'}`}>
                        {log.success ? 'BERHASIL MASUK' : 'PERCOBAAN GAGAL'}
                      </span>
                      <span className="text-xs text-text-muted flex-shrink-0 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(log.attemptedAt).toLocaleString('id-ID', { dateStyle: 'short', timeStyle: 'short' })}
                      </span>
                    </div>
                    <p className="text-xs text-text-muted truncate font-mono">
                      {log.userAgent?.slice(0, 80) || 'Unknown browser'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
