'use client'

import { signIn } from 'next-auth/react'
import { useState, useEffect } from 'react'
import { Shield, Lock, Zap, Eye, ChevronRight } from 'lucide-react'

export default function LoginPage() {
  const [loading, setLoading] = useState(false)
  const [glitching, setGlitching] = useState(false)
  const [terminalLines, setTerminalLines] = useState<string[]>([])

  const handleGoogleLogin = async () => {
    setLoading(true)
    await signIn('google', { callbackUrl: '/chat' })
  }

  // Terminal boot sequence animation
  useEffect(() => {
    const lines = [
      '> Initializing KriptoTalk v2.0...',
      '> Loading ECDH P-521 cipher engine...',
      '> Importing Web Crypto API [OK]',
      '> AES-256-GCM ready [OK]',
      '> HKDF-SHA512 key derivation [OK]',
      '> HMAC-SHA512 authentication [OK]',
      '> Forward secrecy protocol [ACTIVE]',
      '> Zero-knowledge server [ENABLED]',
      '> Awaiting identity verification...',
    ]

    let i = 0
    const interval = setInterval(() => {
      if (i < lines.length) {
        setTerminalLines(prev => [...prev, lines[i]])
        i++
      } else {
        clearInterval(interval)
      }
    }, 300)

    return () => clearInterval(interval)
  }, [])

  // Periodic glitch effect
  useEffect(() => {
    const interval = setInterval(() => {
      setGlitching(true)
      setTimeout(() => setGlitching(false), 200)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-bg-primary hex-bg flex items-center justify-center relative overflow-hidden noise-overlay">
      {/* Animated scan line */}
      <div className="scanline" />

      {/* Background grid */}
      <div className="absolute inset-0 grid-bg opacity-50" />

      {/* Radial glow effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent-primary/5 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent-secondary/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />

      {/* Floating particles */}
      {[...Array(20)].map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 rounded-full opacity-20"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: i % 2 === 0 ? '#00d4ff' : '#7b2fff',
            animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
            animationDelay: `${Math.random() * 3}s`,
          }}
        />
      ))}

      <div className="relative z-10 w-full max-w-md px-6">
        {/* Logo & Title */}
        <div className="text-center mb-8 animate-fade-in">
          {/* Icon */}
          <div className="relative inline-flex items-center justify-center mb-6">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-bg-card to-bg-tertiary border border-border-glow flex items-center justify-center shadow-glow-cyan">
              <Shield className="w-10 h-10 text-accent-primary" strokeWidth={1.5} />
            </div>
            {/* Spinning ring */}
            <div className="absolute inset-0 rounded-2xl border border-accent-primary/30 animate-spin" style={{ animationDuration: '8s' }} />
            <div className="absolute inset-[-4px] rounded-2xl border border-accent-secondary/20 animate-spin" style={{ animationDuration: '12s', animationDirection: 'reverse' }} />
          </div>

          <h1 className={`text-4xl font-bold tracking-tight mb-2 ${glitching ? 'opacity-80' : ''}`}>
            <span className="gradient-text">KriptoTalk</span>
          </h1>
          <p className="text-text-secondary text-sm font-mono tracking-wider">
            END-TO-END ENCRYPTED MESSENGER
          </p>
        </div>

        {/* Main card */}
        <div className="glass rounded-2xl p-8 border border-border-primary shadow-card animate-slide-up">
          {/* Cipher suite badge */}
          <div className="flex items-center gap-2 bg-bg-tertiary rounded-xl p-3 mb-6 border border-border-secondary">
            <Lock className="w-4 h-4 text-accent-primary flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-xs text-text-muted font-mono">Cipher Suite Aktif</p>
              <p className="text-xs text-accent-primary font-mono truncate">
                ECDH-P521 + HKDF-SHA512 + AES-GCM-256
              </p>
            </div>
            <div className="w-2 h-2 rounded-full bg-status-online animate-pulse flex-shrink-0" />
          </div>

          {/* Security features */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            {[
              { icon: Shield, label: 'E2E Encrypted', color: 'text-accent-primary' },
              { icon: Eye, label: 'Zero Knowledge', color: 'text-accent-purple' },
              { icon: Zap, label: 'Forward Secrecy', color: 'text-status-online' },
            ].map(({ icon: Icon, label, color }) => (
              <div key={label} className="flex flex-col items-center gap-1.5 p-3 bg-bg-tertiary rounded-xl border border-border-secondary">
                <Icon className={`w-5 h-5 ${color}`} strokeWidth={1.5} />
                <span className="text-[10px] text-text-secondary text-center leading-tight">{label}</span>
              </div>
            ))}
          </div>

          {/* Google Login Button */}
          <button
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 px-6 py-4 rounded-xl font-semibold text-base transition-all duration-200 relative overflow-hidden group disabled:opacity-70 disabled:cursor-not-allowed"
            style={{
              background: loading
                ? 'linear-gradient(135deg, #0d2040, #1a1a3a)'
                : 'linear-gradient(135deg, #0d3464, #1a2a5e)',
              border: '1px solid #00d4ff44',
              boxShadow: loading ? 'none' : '0 0 20px #00d4ff22, inset 0 1px 0 #00d4ff22',
            }}
          >
            {/* Hover glow */}
            <div className="absolute inset-0 bg-accent-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
            
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-accent-primary/30 border-t-accent-primary rounded-full animate-spin" />
                <span className="text-text-primary">Menghubungkan...</span>
              </>
            ) : (
              <>
                {/* Google Logo */}
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                <span className="text-white">Masuk dengan Google</span>
                <ChevronRight className="w-4 h-4 text-accent-primary ml-auto" />
              </>
            )}
          </button>

          <p className="text-center text-xs text-text-muted mt-4 font-mono">
            Hanya Google OAuth. Tidak ada password.
          </p>
        </div>

        {/* Terminal boot log */}
        <div className="mt-6 bg-black/40 rounded-xl border border-border-secondary p-4 font-mono text-xs animate-fade-in" style={{ animationDelay: '0.5s' }}>
          <div className="flex items-center gap-2 mb-3 pb-2 border-b border-border-secondary">
            <div className="w-3 h-3 rounded-full bg-red-500/60" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
            <div className="w-3 h-3 rounded-full bg-green-500/60" />
            <span className="text-text-muted ml-2">kriptotalk — boot log</span>
          </div>
          <div className="space-y-1 max-h-36 overflow-hidden">
            {terminalLines.map((line, i) => (
              <p key={i} className={`${line.includes('[OK]') || line.includes('[ACTIVE]') || line.includes('[ENABLED]')
                ? 'text-status-online'
                : line.includes('Awaiting')
                  ? 'text-accent-primary animate-pulse'
                  : 'text-text-secondary'
                }`}>
                {line}
              </p>
            ))}
            <span className="text-accent-primary animate-pulse">█</span>
          </div>
        </div>

        {/* Security comparison */}
        <div className="mt-4 glass rounded-xl p-4 border border-border-secondary">
          <p className="text-xs text-text-muted font-mono mb-2 text-center">SECURITY COMPARISON</p>
          <div className="space-y-1.5 text-xs font-mono">
            <div className="flex justify-between items-center">
              <span className="text-text-secondary">Telegram MTProto</span>
              <span className="text-yellow-400">RSA-2048 + AES-256</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-accent-primary font-semibold">KriptoTalk ★</span>
              <span className="text-status-online">P-521 + AES-256-GCM</span>
            </div>
            <div className="h-px bg-border-secondary my-1" />
            <div className="flex justify-between text-text-muted">
              <span>Equivalent RSA</span>
              <span className="text-status-online">~15,360-bit ↑↑</span>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
      `}</style>
    </div>
  )
}
