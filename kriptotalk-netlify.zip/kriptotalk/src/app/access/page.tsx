'use client'

import { useState, useRef, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Shield, Lock, Eye, EyeOff, AlertTriangle, CheckCircle, Loader2 } from 'lucide-react'
import { getAccessPassword, logAccessAttempt } from '@/lib/firebase'
import { sendLoginNotification } from '@/lib/emailNotify'

export default function AccessGatePage() {
  const router = useRouter()
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [status, setStatus] = useState<'idle' | 'loading' | 'error' | 'success'>('idle')
  const [errorMsg, setErrorMsg] = useState('')
  const [attempts, setAttempts] = useState(0)
  const [isLocked, setIsLocked] = useState(false)
  const [lockTimer, setLockTimer] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)
  const lockIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    // Cek apakah sudah punya akses
    const granted = sessionStorage.getItem('kt_access_granted')
    if (granted === 'true') {
      router.replace('/login')
    }
    inputRef.current?.focus()
  }, [router])

  // Countdown timer saat locked
  useEffect(() => {
    if (isLocked && lockTimer > 0) {
      lockIntervalRef.current = setInterval(() => {
        setLockTimer(t => {
          if (t <= 1) {
            setIsLocked(false)
            clearInterval(lockIntervalRef.current!)
            return 0
          }
          return t - 1
        })
      }, 1000)
    }
    return () => {
      if (lockIntervalRef.current) clearInterval(lockIntervalRef.current)
    }
  }, [isLocked, lockTimer])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!password.trim() || status === 'loading' || isLocked) return

    setStatus('loading')
    setErrorMsg('')

    try {
      // Ambil password aktif dari Firebase
      const activePassword = await getAccessPassword()
      const now = new Date()
      const attemptTime = now.toLocaleString('id-ID', {
        dateStyle: 'full',
        timeStyle: 'short',
      })

      // Cek password
      const isCorrect = activePassword !== null && password === activePassword

      // Log ke Firebase
      await logAccessAttempt(isCorrect)

      if (isCorrect) {
        setStatus('success')
        // Simpan akses di session
        sessionStorage.setItem('kt_access_granted', 'true')
        sessionStorage.setItem('kt_access_time', now.toISOString())

        // Redirect ke login Google setelah animasi singkat
        setTimeout(() => {
          router.replace('/login')
        }, 1200)

      } else {
        const newAttempts = attempts + 1
        setAttempts(newAttempts)

        // Kirim notifikasi email ke admin
        await sendLoginNotification({
          success: false,
          attemptTime,
        })

        // Kunci sementara setelah 3x gagal
        if (newAttempts >= 3) {
          setIsLocked(true)
          setLockTimer(30)
          setErrorMsg(`Terlalu banyak percobaan gagal. Tunggu 30 detik.`)
          setAttempts(0)
        } else {
          setErrorMsg(`Kata kunci salah. Percobaan ke-${newAttempts} dari 3.`)
        }

        setStatus('error')
        setPassword('')
        inputRef.current?.focus()
      }
    } catch (err) {
      console.error(err)
      setErrorMsg('Gagal terhubung. Periksa koneksi internet.')
      setStatus('error')
    }
  }

  return (
    <div className="min-h-screen bg-bg-primary flex items-center justify-center relative overflow-hidden noise-overlay">
      {/* Background effects */}
      <div className="absolute inset-0 grid-bg opacity-40" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent-primary/4 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-accent-secondary/4 rounded-full blur-3xl" />
      <div className="scanline" />

      <div className="relative z-10 w-full max-w-sm px-6">
        {/* Logo */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="relative inline-flex items-center justify-center mb-5">
            <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br from-bg-card to-bg-tertiary border flex items-center justify-center transition-all duration-500 ${
              status === 'success'
                ? 'border-status-online shadow-[0_0_30px_rgba(0,230,118,0.3)]'
                : status === 'error'
                ? 'border-red-500/50 shadow-[0_0_20px_rgba(239,68,68,0.2)]'
                : 'border-border-glow shadow-glow-cyan'
            }`}>
              {status === 'success' ? (
                <CheckCircle className="w-10 h-10 text-status-online animate-lock-spin" />
              ) : (
                <Lock className={`w-10 h-10 transition-colors ${
                  status === 'error' ? 'text-red-400' : 'text-accent-primary'
                }`} strokeWidth={1.5} />
              )}
            </div>
            {status !== 'error' && status !== 'success' && (
              <div className="absolute inset-0 rounded-2xl border border-accent-primary/20 animate-spin" style={{ animationDuration: '8s' }} />
            )}
          </div>

          <h1 className="text-3xl font-bold gradient-text mb-1">KriptoTalk</h1>
          <p className="text-text-muted text-xs font-mono tracking-widest">AKSES TERBATAS</p>
        </div>

        {/* Card */}
        <div className={`glass rounded-2xl p-7 border transition-all duration-300 animate-slide-up ${
          status === 'error'
            ? 'border-red-500/30'
            : status === 'success'
            ? 'border-status-online/30'
            : 'border-border-primary'
        }`}>
          {status === 'success' ? (
            <div className="text-center py-4">
              <CheckCircle className="w-12 h-12 text-status-online mx-auto mb-3" />
              <p className="text-text-primary font-semibold">Akses Diberikan</p>
              <p className="text-text-muted text-sm mt-1">Mengalihkan...</p>
              <div className="mt-4 h-1 bg-bg-tertiary rounded-full overflow-hidden">
                <div className="h-full bg-status-online rounded-full animate-[shimmer_1.2s_ease-out_forwards]" style={{ width: '100%' }} />
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-xs font-semibold text-text-secondary mb-2 font-mono tracking-wider">
                  KATA KUNCI AKSES
                </label>
                <div className="relative">
                  <input
                    ref={inputRef}
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={e => { setPassword(e.target.value); setStatus('idle'); setErrorMsg('') }}
                    placeholder={isLocked ? `🔒 Terkunci ${lockTimer}s...` : 'Masukkan kata kunci...'}
                    disabled={isLocked || status === 'loading'}
                    className={`w-full bg-bg-input border rounded-xl px-4 py-3 pr-11 text-text-primary placeholder-text-muted focus:outline-none transition-all text-sm font-mono ${
                      status === 'error'
                        ? 'border-red-500/50 focus:border-red-500'
                        : 'border-border-secondary focus:border-accent-primary/60'
                    } disabled:opacity-50 disabled:cursor-not-allowed`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-secondary transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Error message */}
              {errorMsg && (
                <div className="flex items-start gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2.5 animate-fade-in">
                  <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-red-300">{errorMsg}</p>
                </div>
              )}

              {/* Locked countdown */}
              {isLocked && (
                <div className="h-1.5 bg-bg-tertiary rounded-full overflow-hidden">
                  <div
                    className="h-full bg-red-500 rounded-full transition-all duration-1000"
                    style={{ width: `${(lockTimer / 30) * 100}%` }}
                  />
                </div>
              )}

              {/* Submit button */}
              <button
                type="submit"
                disabled={!password.trim() || status === 'loading' || isLocked}
                className="w-full flex items-center justify-center gap-2.5 py-3 rounded-xl font-semibold text-sm transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed hover:brightness-110 active:scale-[0.98]"
                style={{
                  background: 'linear-gradient(135deg, #0d3464, #1a1a3e)',
                  border: '1px solid rgba(0,212,255,0.25)',
                  boxShadow: '0 0 15px rgba(0,212,255,0.1)',
                }}
              >
                {status === 'loading' ? (
                  <>
                    <Loader2 className="w-4 h-4 text-accent-primary animate-spin" />
                    <span className="text-text-primary">Memeriksa...</span>
                  </>
                ) : (
                  <>
                    <Shield className="w-4 h-4 text-accent-primary" />
                    <span className="text-white">Masuk</span>
                  </>
                )}
              </button>

              <p className="text-center text-xs text-text-muted font-mono">
                Hubungi admin jika tidak punya kata kunci
              </p>
            </form>
          )}
        </div>

        {/* Security note */}
        <div className="mt-4 flex items-center justify-center gap-1.5">
          <Lock className="w-3 h-3 text-text-muted" />
          <span className="text-xs text-text-muted font-mono">Percobaan gagal dicatat & dilaporkan</span>
        </div>
      </div>
    </div>
  )
}
