import { auth } from '@/auth'
import { redirect } from 'next/navigation'

export default async function Home() {
  const session = await auth()
  if (session?.user) {
    redirect('/chat')
  } else {
    // Redirect ke gerbang akses dulu, baru login Google
    redirect('/access')
  }
}
