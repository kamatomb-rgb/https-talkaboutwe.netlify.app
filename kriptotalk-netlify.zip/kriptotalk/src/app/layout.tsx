import type { Metadata } from 'next'
import { Inter, JetBrains_Mono } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'KriptoTalk — Encrypted Messenger',
  description: 'End-to-end encrypted messaging with ECDH P-521 + AES-256-GCM. More secure than Telegram.',
  keywords: ['encrypted chat', 'E2E encryption', 'secure messenger', 'ECDH', 'AES-GCM'],
  icons: {
    icon: '/favicon.ico',
  },
  openGraph: {
    title: 'KriptoTalk',
    description: 'Military-grade encrypted messaging',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="id" className="dark">
      <body className={`${inter.variable} ${jetbrainsMono.variable} font-sans antialiased`}>
        {children}
      </body>
    </html>
  )
}
