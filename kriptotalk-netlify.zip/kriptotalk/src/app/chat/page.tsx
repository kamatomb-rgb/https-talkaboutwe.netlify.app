'use client'

import { useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useChatStore } from '@/lib/store/chatStore'
import { Sidebar } from '@/components/chat/Sidebar'
import { ChatWindow } from '@/components/chat/ChatWindow'
import { WelcomeScreen } from '@/components/chat/WelcomeScreen'
import type { KUser } from '@/types'

export default function ChatPage() {
  const { data: session } = useSession()
  const { setCurrentUser, loadInitialData, activeChat, currentUser, sidebarOpen } = useChatStore()

  // Initialize current user from session
  useEffect(() => {
    if (session?.user && !currentUser) {
      const user: KUser = {
        id: session.user.id || session.user.email || 'me',
        name: session.user.name || 'User',
        email: session.user.email || '',
        avatar: session.user.image || `https://api.dicebear.com/7.x/avataaars/svg?seed=${session.user.name}`,
        status: 'online',
      }
      setCurrentUser(user)
    }
  }, [session, currentUser, setCurrentUser])

  // Load initial demo data after user is set
  useEffect(() => {
    if (currentUser) {
      loadInitialData()
    }
  }, [currentUser, loadInitialData])

  if (!session?.user) return null

  return (
    <div className="h-screen flex bg-bg-primary overflow-hidden">
      {/* Sidebar */}
      <div className={`
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        fixed md:relative md:translate-x-0
        z-30 md:z-auto
        transition-transform duration-300 ease-in-out
        h-full
        w-80 lg:w-96
        flex-shrink-0
      `}>
        <Sidebar />
      </div>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-20 md:hidden"
          onClick={() => useChatStore.getState().toggleSidebar()}
        />
      )}

      {/* Chat area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {activeChat ? (
          <ChatWindow />
        ) : (
          <WelcomeScreen />
        )}
      </div>
    </div>
  )
}
