/**
 * ============================================================
 * KriptoTalk - Global State Store (Zustand)
 * ============================================================
 * Manages all chat state, encryption keys, and real-time simulation
 */

import { create } from 'zustand'
import { subscribeWithSelector } from 'zustand/middleware'
import { v4 as uuidv4 } from 'uuid'
import type { ChatStore, Chat, Message, KUser, SecretChatConfig } from '@/types'
import {
  generateIdentityKeyPair,
  exportPublicKey,
  exportPrivateKey,
  importPublicKey,
  importPrivateKey,
  encryptMessage,
  decryptMessage,
  serializePublicKey,
} from '@/lib/crypto/encryption'

// ============================================================
// Mock Users (for demo — in production these come from a DB)
// ============================================================
export const MOCK_USERS: KUser[] = [
  {
    id: 'user_aria_001',
    name: 'Aria Santoso',
    email: 'aria@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aria&backgroundColor=b6e3f4',
    status: 'online',
    publicKey: undefined,
  },
  {
    id: 'user_budi_002',
    name: 'Budi Raharja',
    email: 'budi@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Budi&backgroundColor=ffd5dc',
    status: 'online',
    publicKey: undefined,
  },
  {
    id: 'user_citra_003',
    name: 'Citra Dewi',
    email: 'citra@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Citra&backgroundColor=c0aede',
    status: 'away',
    lastSeen: new Date(Date.now() - 5 * 60 * 1000),
    publicKey: undefined,
  },
  {
    id: 'user_dian_004',
    name: 'Dian Permata',
    email: 'dian@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Dian&backgroundColor=d1d4f9',
    status: 'offline',
    lastSeen: new Date(Date.now() - 2 * 60 * 60 * 1000),
    publicKey: undefined,
  },
  {
    id: 'user_eko_005',
    name: 'Eko Prasetyo',
    email: 'eko@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Eko&backgroundColor=b6e3f4',
    status: 'online',
    publicKey: undefined,
  },
]

// In-memory "encrypted" message store (simulates server storage)
// Server only sees ciphertext, never plaintext
const serverMessageStore: Record<string, { encryptedPayload: import('@/types').EncryptedPayload; meta: Omit<Message, 'content' | 'encryptedPayload'> }[]> = {}

// In-memory key registry (simulates public key server)
const publicKeyRegistry: Record<string, CryptoKey> = {}

// ============================================================
// Store Definition
// ============================================================

export const useChatStore = create<ChatStore>()(
  subscribeWithSelector((set, get) => ({
    // Initial state
    currentUser: null,
    chats: [],
    messages: {},
    activeChat: null,
    activeChatData: null,
    typingIndicators: {},
    onlineUsers: new Set(['user_aria_001', 'user_budi_002', 'user_eko_005']),
    searchQuery: '',
    sidebarOpen: true,
    keyPairs: {},
    peerPublicKeys: {},

    // ============================================================
    // Load initial demo data
    // ============================================================
    loadInitialData: () => {
      const { currentUser } = get()
      if (!currentUser) return

      const now = new Date()
      const mkTime = (minutesAgo: number) => new Date(now.getTime() - minutesAgo * 60000)

      const demoChats: Chat[] = [
        {
          id: 'chat_aria_private',
          type: 'private',
          participants: [currentUser.id, 'user_aria_001'],
          participantDetails: [currentUser, MOCK_USERS[0]],
          unreadCount: 2,
          createdAt: mkTime(120),
          updatedAt: mkTime(2),
          isEncrypted: true,
          lastMessage: {
            id: 'msg_preview_1',
            chatId: 'chat_aria_private',
            senderId: 'user_aria_001',
            content: '🔐 [Encrypted message]',
            type: 'text',
            status: 'delivered',
            timestamp: mkTime(2),
            reactions: [],
          },
        },
        {
          id: 'chat_secret_budi',
          type: 'secret',
          participants: [currentUser.id, 'user_budi_002'],
          participantDetails: [currentUser, MOCK_USERS[1]],
          unreadCount: 0,
          createdAt: mkTime(60),
          updatedAt: mkTime(10),
          isEncrypted: true,
          secretChatConfig: {
            selfDestructDuration: 300,
            selfDestructLabel: '5 menit',
            encryptionLevel: 'paranoid',
          },
          lastMessage: {
            id: 'msg_preview_2',
            chatId: 'chat_secret_budi',
            senderId: currentUser.id,
            content: '🔐 [Encrypted message]',
            type: 'text',
            status: 'read',
            timestamp: mkTime(10),
            reactions: [],
          },
        },
        {
          id: 'chat_group_dev',
          type: 'group',
          name: 'Tim DevSecOps 🔒',
          avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=DevSecOps',
          participants: [currentUser.id, 'user_aria_001', 'user_budi_002', 'user_citra_003'],
          participantDetails: [currentUser, ...MOCK_USERS.slice(0, 3)],
          unreadCount: 5,
          createdAt: mkTime(1440),
          updatedAt: mkTime(30),
          isEncrypted: true,
          lastMessage: {
            id: 'msg_preview_3',
            chatId: 'chat_group_dev',
            senderId: 'user_citra_003',
            content: '🔐 [Encrypted message]',
            type: 'text',
            status: 'delivered',
            timestamp: mkTime(30),
            reactions: [],
          },
        },
        {
          id: 'chat_citra_private',
          type: 'private',
          participants: [currentUser.id, 'user_citra_003'],
          participantDetails: [currentUser, MOCK_USERS[2]],
          unreadCount: 0,
          createdAt: mkTime(2880),
          updatedAt: mkTime(90),
          isEncrypted: true,
          lastMessage: {
            id: 'msg_preview_4',
            chatId: 'chat_citra_private',
            senderId: currentUser.id,
            content: '🔐 [Encrypted message]',
            type: 'text',
            status: 'read',
            timestamp: mkTime(90),
            reactions: [],
          },
        },
      ]

      // Demo messages (shown as decrypted for UI purposes)
      const demoMessages: Record<string, Message[]> = {
        'chat_aria_private': [
          {
            id: 'msg_a1',
            chatId: 'chat_aria_private',
            senderId: 'user_aria_001',
            content: 'Halo! Udah setup KriptoTalk? 🔐',
            type: 'text',
            status: 'read',
            timestamp: mkTime(45),
            reactions: [{ emoji: '👍', userIds: [currentUser.id] }],
          },
          {
            id: 'msg_a2',
            chatId: 'chat_aria_private',
            senderId: currentUser.id,
            content: 'Iya! Baru aja. Enkripsinya pakai ECDH P-521 + AES-256-GCM 🚀',
            type: 'text',
            status: 'read',
            timestamp: mkTime(43),
            reactions: [],
          },
          {
            id: 'msg_a3',
            chatId: 'chat_aria_private',
            senderId: 'user_aria_001',
            content: 'Wow, itu lebih kuat dari Telegram! Forward secrecy juga kan?',
            type: 'text',
            status: 'read',
            timestamp: mkTime(40),
            reactions: [{ emoji: '❤️', userIds: [currentUser.id] }],
          },
          {
            id: 'msg_a4',
            chatId: 'chat_aria_private',
            senderId: currentUser.id,
            content: 'Betul! Setiap pesan pakai ephemeral key baru. Kalau key bocor, pesan lama tetap aman 💪',
            type: 'text',
            status: 'read',
            timestamp: mkTime(38),
            reactions: [],
            replyToId: 'msg_a3',
          },
          {
            id: 'msg_a5',
            chatId: 'chat_aria_private',
            senderId: 'user_aria_001',
            content: 'Cipher suite lengkap: ECDH-P521 + HKDF-SHA512 + AES-GCM-256 + HMAC-SHA512 🔒',
            type: 'text',
            status: 'delivered',
            timestamp: mkTime(2),
            reactions: [],
          },
          {
            id: 'msg_a6',
            chatId: 'chat_aria_private',
            senderId: 'user_aria_001',
            content: 'Bisa coba Secret Chat juga? Ada fitur self-destruct timer!',
            type: 'text',
            status: 'delivered',
            timestamp: mkTime(1),
            reactions: [],
          },
        ],
        'chat_secret_budi': [
          {
            id: 'msg_b1',
            chatId: 'chat_secret_budi',
            senderId: 'user_budi_002',
            content: '🔴 Secret Chat aktif. Pesan akan terhapus dalam 5 menit.',
            type: 'system',
            status: 'read',
            timestamp: mkTime(60),
            reactions: [],
          },
          {
            id: 'msg_b2',
            chatId: 'chat_secret_budi',
            senderId: 'user_budi_002',
            content: 'Ini jalur komunikasi terenkripsi tingkat paranoid 😈',
            type: 'text',
            status: 'read',
            timestamp: mkTime(58),
            reactions: [],
            selfDestructAt: new Date(Date.now() + 2 * 60 * 1000),
          },
          {
            id: 'msg_b3',
            chatId: 'chat_secret_budi',
            senderId: currentUser.id,
            content: 'Perfect. Keys di-generate di device, server cuma terima ciphertext.',
            type: 'text',
            status: 'read',
            timestamp: mkTime(10),
            reactions: [{ emoji: '🔥', userIds: ['user_budi_002'] }],
            selfDestructAt: new Date(Date.now() + 5 * 60 * 1000),
          },
        ],
        'chat_group_dev': [
          {
            id: 'msg_g1',
            chatId: 'chat_group_dev',
            senderId: 'user_aria_001',
            content: 'Tim, KriptoTalk sudah siap! Security audit passed ✅',
            type: 'text',
            status: 'read',
            timestamp: mkTime(120),
            reactions: [
              { emoji: '🎉', userIds: [currentUser.id, 'user_budi_002'] },
              { emoji: '🔥', userIds: ['user_citra_003'] },
            ],
          },
          {
            id: 'msg_g2',
            chatId: 'chat_group_dev',
            senderId: 'user_budi_002',
            content: 'Mantap! Cipher suite kita lebih kuat dari Telegram MTProto 2.0',
            type: 'text',
            status: 'read',
            timestamp: mkTime(115),
            reactions: [],
          },
          {
            id: 'msg_g3',
            chatId: 'chat_group_dev',
            senderId: currentUser.id,
            content: 'P-521 curve itu setara ~15360-bit RSA. Quantum-resistant level! 🛡️',
            type: 'text',
            status: 'read',
            timestamp: mkTime(110),
            reactions: [{ emoji: '👍', userIds: ['user_aria_001', 'user_citra_003'] }],
          },
          {
            id: 'msg_g4',
            chatId: 'chat_group_dev',
            senderId: 'user_citra_003',
            content: 'HKDF-SHA512 untuk key derivation juga bagus. Zero-knowledge server! 💯',
            type: 'text',
            status: 'delivered',
            timestamp: mkTime(30),
            reactions: [],
          },
          {
            id: 'msg_g5',
            chatId: 'chat_group_dev',
            senderId: 'user_aria_001',
            content: 'Next: implement post-quantum crypto dengan CRYSTALS-Kyber? 🤔',
            type: 'text',
            status: 'delivered',
            timestamp: mkTime(28),
            reactions: [{ emoji: '🤯', userIds: [currentUser.id, 'user_budi_002'] }],
          },
        ],
        'chat_citra_private': [
          {
            id: 'msg_c1',
            chatId: 'chat_citra_private',
            senderId: currentUser.id,
            content: 'Citra, udah coba fitur enkripsinya?',
            type: 'text',
            status: 'read',
            timestamp: mkTime(100),
            reactions: [],
          },
          {
            id: 'msg_c2',
            chatId: 'chat_citra_private',
            senderId: 'user_citra_003',
            content: 'Udah! Keren banget. Key fingerprint bisa diverify juga kan?',
            type: 'text',
            status: 'read',
            timestamp: mkTime(95),
            reactions: [{ emoji: '❤️', userIds: [currentUser.id] }],
          },
          {
            id: 'msg_c3',
            chatId: 'chat_citra_private',
            senderId: currentUser.id,
            content: 'Iya! SHA-512 hash dari public key. Mirip Signal safety numbers.',
            type: 'text',
            status: 'read',
            timestamp: mkTime(90),
            reactions: [],
          },
        ],
      }

      set({
        chats: demoChats,
        messages: demoMessages,
      })
    },

    // ============================================================
    // Set current user
    // ============================================================
    setCurrentUser: (user) => set({ currentUser: user }),

    // ============================================================
    // Set active chat
    // ============================================================
    setActiveChat: (chatId) => {
      if (!chatId) {
        set({ activeChat: null, activeChatData: null })
        return
      }
      const chat = get().chats.find(c => c.id === chatId)
      set({ activeChat: chatId, activeChatData: chat || null })
      // Mark messages as read
      get().markAsRead(chatId)
    },

    // ============================================================
    // Send encrypted message
    // ============================================================
    sendMessage: async (chatId, content, replyToId) => {
      const { currentUser, chats, messages, keyPairs } = get()
      if (!currentUser || !content.trim()) return

      const chat = chats.find(c => c.id === chatId)
      if (!chat) return

      const msgId = uuidv4()
      const now = new Date()

      // Determine self-destruct time for secret chats
      let selfDestructAt: Date | undefined
      if (chat.type === 'secret' && chat.secretChatConfig) {
        selfDestructAt = new Date(now.getTime() + chat.secretChatConfig.selfDestructDuration * 1000)
      }

      // Try to encrypt the message if we have keys
      let encryptedPayload: import('@/types').EncryptedPayload | undefined
      let storedContent = content

      const chatKeyPair = keyPairs[chatId]
      if (chatKeyPair) {
        try {
          const publicKey = await importPublicKey(chatKeyPair.publicKey)
          encryptedPayload = await encryptMessage(content, publicKey)
          storedContent = '🔐 [Encrypted message]'
        } catch (e) {
          console.warn('Encryption failed, sending as plaintext for demo:', e)
        }
      }

      const newMessage: Message = {
        id: msgId,
        chatId,
        senderId: currentUser.id,
        content,          // Keep in memory for display
        encryptedPayload, // This would be stored on server
        type: 'text',
        status: 'sending',
        timestamp: now,
        reactions: [],
        replyToId,
        replyTo: replyToId ? messages[chatId]?.find(m => m.id === replyToId) : undefined,
        selfDestructAt,
      }

      // Optimistic update
      set(state => ({
        messages: {
          ...state.messages,
          [chatId]: [...(state.messages[chatId] || []), newMessage],
        },
        chats: state.chats.map(c =>
          c.id === chatId
            ? { ...c, lastMessage: newMessage, updatedAt: now, unreadCount: 0 }
            : c
        ),
      }))

      // Simulate network delay
      await new Promise(r => setTimeout(r, 300 + Math.random() * 400))

      // Update to "sent" status
      set(state => ({
        messages: {
          ...state.messages,
          [chatId]: state.messages[chatId].map(m =>
            m.id === msgId ? { ...m, status: 'sent' } : m
          ),
        },
      }))

      // Simulate "delivered" after another delay
      setTimeout(() => {
        set(state => ({
          messages: {
            ...state.messages,
            [chatId]: (state.messages[chatId] || []).map(m =>
              m.id === msgId ? { ...m, status: 'delivered' } : m
            ),
          },
        }))
      }, 1000 + Math.random() * 1000)

      // Simulate auto-reply from the other person (for demo)
      if (chat.type === 'private' || chat.type === 'secret') {
        const otherUserId = chat.participants.find(p => p !== currentUser.id)
        const otherUser = MOCK_USERS.find(u => u.id === otherUserId)
        if (otherUser && get().onlineUsers.has(otherUserId!)) {
          simulateAutoReply(chatId, otherUser, content, selfDestructAt)
        }
      }

      // Handle self-destruct
      if (selfDestructAt) {
        const delay = selfDestructAt.getTime() - Date.now()
        setTimeout(() => {
          set(state => ({
            messages: {
              ...state.messages,
              [chatId]: (state.messages[chatId] || []).map(m =>
                m.id === msgId ? { ...m, isDeleted: true, content: '💨 Message self-destructed' } : m
              ),
            },
          }))
        }, delay)
      }
    },

    // ============================================================
    // Add reaction to message
    // ============================================================
    addReaction: (chatId, messageId, emoji) => {
      const { currentUser } = get()
      if (!currentUser) return

      set(state => ({
        messages: {
          ...state.messages,
          [chatId]: (state.messages[chatId] || []).map(m => {
            if (m.id !== messageId) return m
            const existingReaction = m.reactions.find(r => r.emoji === emoji)
            if (existingReaction) {
              const hasReacted = existingReaction.userIds.includes(currentUser.id)
              return {
                ...m,
                reactions: hasReacted
                  ? m.reactions.map(r => r.emoji === emoji
                    ? { ...r, userIds: r.userIds.filter(id => id !== currentUser.id) }
                    : r
                  ).filter(r => r.userIds.length > 0)
                  : m.reactions.map(r => r.emoji === emoji
                    ? { ...r, userIds: [...r.userIds, currentUser.id] }
                    : r
                  ),
              }
            }
            return {
              ...m,
              reactions: [...m.reactions, { emoji, userIds: [currentUser.id] }],
            }
          }),
        },
      }))
    },

    // ============================================================
    // Delete message
    // ============================================================
    deleteMessage: (chatId, messageId, forEveryone) => {
      set(state => ({
        messages: {
          ...state.messages,
          [chatId]: (state.messages[chatId] || []).map(m =>
            m.id === messageId
              ? {
                ...m,
                isDeleted: true,
                deletedForEveryone: forEveryone,
                content: forEveryone ? '🗑️ Message deleted' : '🗑️ You deleted this message',
              }
              : m
          ),
        },
      }))
    },

    // ============================================================
    // Typing indicator
    // ============================================================
    setTyping: (chatId, userId, isTyping) => {
      set(state => ({
        typingIndicators: {
          ...state.typingIndicators,
          [chatId]: isTyping
            ? [...new Set([...(state.typingIndicators[chatId] || []), userId])]
            : (state.typingIndicators[chatId] || []).filter(id => id !== userId),
        },
      }))
    },

    // ============================================================
    // Mark chat as read
    // ============================================================
    markAsRead: (chatId) => {
      set(state => ({
        chats: state.chats.map(c =>
          c.id === chatId ? { ...c, unreadCount: 0 } : c
        ),
        messages: {
          ...state.messages,
          [chatId]: (state.messages[chatId] || []).map(m =>
            m.senderId !== state.currentUser?.id ? { ...m, status: 'read' } : m
          ),
        },
      }))
    },

    // ============================================================
    // Create private chat
    // ============================================================
    createPrivateChat: async (participant) => {
      const { currentUser, chats } = get()
      if (!currentUser) return ''

      // Check if chat already exists
      const existing = chats.find(c =>
        c.type === 'private' &&
        c.participants.includes(participant.id) &&
        c.participants.includes(currentUser.id)
      )
      if (existing) return existing.id

      const chatId = `chat_${uuidv4()}`
      const newChat: Chat = {
        id: chatId,
        type: 'private',
        participants: [currentUser.id, participant.id],
        participantDetails: [currentUser, participant],
        unreadCount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
        isEncrypted: true,
      }

      set(state => ({
        chats: [newChat, ...state.chats],
        messages: { ...state.messages, [chatId]: [] },
      }))

      await get().initEncryption(chatId)
      return chatId
    },

    // ============================================================
    // Create group chat
    // ============================================================
    createGroupChat: async (name, participants) => {
      const { currentUser } = get()
      if (!currentUser) return ''

      const chatId = `chat_group_${uuidv4()}`
      const allParticipants = [currentUser, ...participants].slice(0, 10)

      const newChat: Chat = {
        id: chatId,
        type: 'group',
        name,
        avatar: `https://api.dicebear.com/7.x/identicon/svg?seed=${name}`,
        participants: allParticipants.map(p => p.id),
        participantDetails: allParticipants,
        unreadCount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
        isEncrypted: true,
      }

      set(state => ({
        chats: [newChat, ...state.chats],
        messages: { ...state.messages, [chatId]: [] },
      }))

      await get().initEncryption(chatId)
      return chatId
    },

    // ============================================================
    // Create secret chat
    // ============================================================
    createSecretChat: async (participant, config) => {
      const { currentUser } = get()
      if (!currentUser) return ''

      const chatId = `chat_secret_${uuidv4()}`
      const newChat: Chat = {
        id: chatId,
        type: 'secret',
        participants: [currentUser.id, participant.id],
        participantDetails: [currentUser, participant],
        unreadCount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
        isEncrypted: true,
        secretChatConfig: config,
      }

      const systemMsg: Message = {
        id: uuidv4(),
        chatId,
        senderId: 'system',
        content: `🔴 Secret Chat dimulai. Pesan akan terhapus dalam ${config.selfDestructLabel}. Enkripsi level: ${config.encryptionLevel === 'paranoid' ? 'PARANOID 🔥' : 'STANDARD'}`,
        type: 'system',
        status: 'read',
        timestamp: new Date(),
        reactions: [],
      }

      set(state => ({
        chats: [newChat, ...state.chats],
        messages: { ...state.messages, [chatId]: [systemMsg] },
      }))

      await get().initEncryption(chatId)
      return chatId
    },

    // ============================================================
    // Initialize encryption for a chat
    // Generates ECDH P-521 key pair and stores it
    // ============================================================
    initEncryption: async (chatId) => {
      const { currentUser } = get()
      if (!currentUser) return

      try {
        const keyPair = await generateIdentityKeyPair()
        const publicKeyJwk = await exportPublicKey(keyPair.publicKey)
        const privateKeyJwk = await exportPrivateKey(keyPair.privateKey)

        // Store serialized keys in state
        set(state => ({
          keyPairs: {
            ...state.keyPairs,
            [chatId]: {
              publicKey: publicKeyJwk,
              privateKey: privateKeyJwk,
            },
          },
        }))

        // Register public key in "server" registry
        publicKeyRegistry[`${currentUser.id}_${chatId}`] = keyPair.publicKey

        console.log(`✅ ECDH P-521 keys generated for chat ${chatId}`)
      } catch (e) {
        console.error('Key generation failed:', e)
      }
    },

    setSearchQuery: (q) => set({ searchQuery: q }),
    toggleSidebar: () => set(state => ({ sidebarOpen: !state.sidebarOpen })),
  }))
)

// ============================================================
// Simulate auto-reply (for demo purposes)
// ============================================================
function simulateAutoReply(
  chatId: string,
  sender: KUser,
  lastMessage: string,
  selfDestructAt?: Date
) {
  const replies = [
    'Siap! Diterima dengan aman 🔒',
    'Enkripsi end-to-end memang yang terbaik 💪',
    'ECDH P-521 > RSA-2048. No contest! 🚀',
    'Server kita cuma lihat ciphertext hehe 😄',
    'Forward secrecy on! Keys ephemeral per pesan 🔑',
    'Quantum-resistant cipher? Kita pakai kurva terkuat 🛡️',
    'Zero-knowledge server architecture! 🏆',
    '👍',
    '❤️ setuju!',
    'Mantap jiwa!',
  ]

  const delay = 1500 + Math.random() * 3000

  // Show typing indicator
  setTimeout(() => {
    useChatStore.getState().setTyping(chatId, sender.id, true)
  }, 500)

  setTimeout(() => {
    useChatStore.getState().setTyping(chatId, sender.id, false)

    const content = replies[Math.floor(Math.random() * replies.length)]
    const msgId = uuidv4()
    const now = new Date()

    const autoMsg: Message = {
      id: msgId,
      chatId,
      senderId: sender.id,
      content,
      type: 'text',
      status: 'delivered',
      timestamp: now,
      reactions: [],
      selfDestructAt,
    }

    useChatStore.setState(state => ({
      messages: {
        ...state.messages,
        [chatId]: [...(state.messages[chatId] || []), autoMsg],
      },
      chats: state.chats.map(c =>
        c.id === chatId
          ? { ...c, lastMessage: autoMsg, updatedAt: now }
          : c
      ),
    }))

    // Handle self-destruct for auto-reply too
    if (selfDestructAt) {
      const delay = selfDestructAt.getTime() - Date.now()
      setTimeout(() => {
        useChatStore.setState(state => ({
          messages: {
            ...state.messages,
            [chatId]: (state.messages[chatId] || []).map(m =>
              m.id === msgId ? { ...m, isDeleted: true, content: '💨 Message self-destructed' } : m
            ),
          },
        }))
      }, delay)
    }
  }, delay)
}
