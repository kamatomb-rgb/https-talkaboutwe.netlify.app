import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { formatDistanceToNow, format, isToday, isYesterday } from 'date-fns'
import { id as localeId } from 'date-fns/locale'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatMessageTime(date: Date): string {
  return format(date, 'HH:mm')
}

export function formatChatListTime(date: Date): string {
  if (isToday(date)) return format(date, 'HH:mm')
  if (isYesterday(date)) return 'Kemarin'
  return format(date, 'dd/MM/yy')
}

export function formatLastSeen(date: Date): string {
  return `terakhir ${formatDistanceToNow(date, { addSuffix: true, locale: localeId })}`
}

export function getInitials(name: string): string {
  return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
}

export function truncate(str: string, maxLen: number): string {
  if (str.length <= maxLen) return str
  return str.slice(0, maxLen) + '…'
}

export const SELF_DESTRUCT_OPTIONS = [
  { label: '1 menit', value: 60 },
  { label: '5 menit', value: 300 },
  { label: '1 jam', value: 3600 },
  { label: '6 jam', value: 21600 },
  { label: '1 hari', value: 86400 },
]

export const EMOJI_REACTIONS = ['❤️', '👍', '😂', '😮', '😢', '🔥', '👏', '🎉']
