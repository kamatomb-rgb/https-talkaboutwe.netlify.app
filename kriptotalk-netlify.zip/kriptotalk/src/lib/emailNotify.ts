/**
 * ============================================================
 * KriptoTalk — Email Notifikasi via EmailJS
 * ============================================================
 * EmailJS gratis (200 email/bulan).
 * Setup: https://www.emailjs.com/
 *
 * Cara setup EmailJS:
 * 1. Daftar di emailjs.com
 * 2. Add Email Service (Gmail recommended)
 * 3. Create Template dengan variabel: {{to_email}}, {{attempt_time}},
 *    {{user_email}}, {{status}}, {{user_agent}}
 * 4. Copy Service ID, Template ID, Public Key ke .env.local
 */

const EMAILJS_SERVICE_ID = process.env.NEXT_PUBLIC_EMAILJS_SERVICE_ID || ''
const EMAILJS_TEMPLATE_ID = process.env.NEXT_PUBLIC_EMAILJS_TEMPLATE_ID || ''
const EMAILJS_PUBLIC_KEY = process.env.NEXT_PUBLIC_EMAILJS_PUBLIC_KEY || ''
const ADMIN_EMAIL = 'k.amato.m.b@gmail.com'

interface EmailParams {
  success: boolean
  userEmail?: string
  attemptTime: string
}

/**
 * Kirim notifikasi email ke admin saat ada percobaan login gagal
 */
export async function sendLoginNotification({
  success,
  userEmail,
  attemptTime,
}: EmailParams): Promise<void> {
  // Jika EmailJS belum dikonfigurasi, skip tanpa error
  if (!EMAILJS_SERVICE_ID || !EMAILJS_TEMPLATE_ID || !EMAILJS_PUBLIC_KEY) {
    console.warn('EmailJS belum dikonfigurasi — notifikasi email dilewati')
    return
  }

  // Hanya kirim email untuk percobaan GAGAL
  if (success) return

  try {
    // Dynamic import agar tidak memperlambat initial load
    const emailjs = await import('@emailjs/browser')
    emailjs.init(EMAILJS_PUBLIC_KEY)

    await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
      to_email: ADMIN_EMAIL,
      status: success ? '✅ BERHASIL MASUK' : '❌ PERCOBAAN GAGAL',
      user_email: userEmail || 'Tidak diketahui',
      attempt_time: attemptTime,
      user_agent: typeof navigator !== 'undefined'
        ? navigator.userAgent.slice(0, 100)
        : 'Unknown',
    })

    console.log('📧 Notifikasi email terkirim ke admin')
  } catch (err) {
    // Gagal kirim email tidak boleh crash app
    console.warn('EmailJS gagal kirim:', err)
  }
}
