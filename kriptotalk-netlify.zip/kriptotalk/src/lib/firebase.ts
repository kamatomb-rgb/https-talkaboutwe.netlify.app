/**
 * ============================================================
 * KriptoTalk — Firebase Configuration
 * ============================================================
 * Ganti nilai di bawah dengan config Firebase project kamu.
 * Cara dapat config: Firebase Console → Project Settings → Your apps
 */

import { initializeApp, getApps } from 'firebase/app'
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  addDoc,
  collection,
  query,
  orderBy,
  limit,
  getDocs,
  serverTimestamp,
} from 'firebase/firestore'

// ── GANTI BAGIAN INI DENGAN CONFIG FIREBASE KAMU ──────────────
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || 'YOUR_API_KEY',
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || 'YOUR_PROJECT.firebaseapp.com',
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || 'YOUR_PROJECT_ID',
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || 'YOUR_PROJECT.appspot.com',
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || 'YOUR_SENDER_ID',
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || 'YOUR_APP_ID',
}
// ──────────────────────────────────────────────────────────────

// Inisialisasi Firebase (singleton)
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0]
export const db = getFirestore(app)

// ============================================================
// KONSTANTA
// ============================================================
const ACCESS_DOC = 'config/access'       // Dokumen password aktif
const LOGS_COLLECTION = 'access_logs'    // Koleksi log percobaan masuk
const ADMIN_EMAIL = 'k.amato.m.b@gmail.com'

// ============================================================
// TIPE DATA
// ============================================================
export interface AccessLog {
  id?: string
  timestamp: Date
  success: boolean
  userEmail?: string        // Email Google user (kalau sudah login Google)
  ipHint?: string           // Bukan IP asli, hanya hint browser
  userAgent?: string
  attemptedAt: string       // ISO string untuk tampilan
}

// ============================================================
// FUNGSI UTAMA
// ============================================================

/**
 * Ambil password akses aktif dari Firestore
 * Dokumen: config/access → { password: "xxx", updatedAt: timestamp }
 */
export async function getAccessPassword(): Promise<string | null> {
  try {
    const ref = doc(db, ACCESS_DOC)
    const snap = await getDoc(ref)
    if (snap.exists()) {
      return snap.data().password as string
    }
    return null
  } catch (err) {
    console.error('Firebase: gagal ambil password:', err)
    return null
  }
}

/**
 * Set/ubah password akses (hanya admin)
 */
export async function setAccessPassword(newPassword: string): Promise<boolean> {
  try {
    const ref = doc(db, ACCESS_DOC)
    await setDoc(ref, {
      password: newPassword,
      updatedAt: serverTimestamp(),
      updatedBy: ADMIN_EMAIL,
    })
    return true
  } catch (err) {
    console.error('Firebase: gagal simpan password:', err)
    return false
  }
}

/**
 * Catat percobaan login ke Firestore
 */
export async function logAccessAttempt(
  success: boolean,
  userEmail?: string
): Promise<void> {
  try {
    const now = new Date()
    await addDoc(collection(db, LOGS_COLLECTION), {
      timestamp: serverTimestamp(),
      attemptedAt: now.toISOString(),
      success,
      userEmail: userEmail || 'unknown',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'server',
    })
  } catch (err) {
    console.error('Firebase: gagal log:', err)
  }
}

/**
 * Ambil 50 log terbaru (untuk admin)
 */
export async function getAccessLogs(): Promise<AccessLog[]> {
  try {
    const q = query(
      collection(db, LOGS_COLLECTION),
      orderBy('timestamp', 'desc'),
      limit(50)
    )
    const snap = await getDocs(q)
    return snap.docs.map(d => ({
      id: d.id,
      ...d.data(),
      timestamp: d.data().timestamp?.toDate?.() || new Date(),
    })) as AccessLog[]
  } catch (err) {
    console.error('Firebase: gagal ambil log:', err)
    return []
  }
}

/**
 * Inisialisasi password default jika belum ada di Firestore
 * Dipanggil pertama kali setup
 */
export async function initDefaultPassword(defaultPw: string): Promise<void> {
  const existing = await getAccessPassword()
  if (!existing) {
    await setAccessPassword(defaultPw)
    console.log('✅ Password default berhasil disimpan ke Firebase')
  }
}
