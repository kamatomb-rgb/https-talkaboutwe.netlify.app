// ============================================
// KriptoTalk - Core Type Definitions
// ============================================

export type UserStatus = 'online' | 'away' | 'offline'

export interface KUser {
  id: string
  name: string
  email: string
  avatar: string
  status: UserStatus
  lastSeen?: Date
  publicKey?: string // Serialized CryptoKey (JWK format)
}

// ============================================
// Encryption Types
// ============================================

export interface KeyPair {
  publicKey: CryptoKey
  privateKey: CryptoKey
}

export interface SerializedKeyPair {
  publicKey: JsonWebKey
  privateKey: JsonWebKey
}

export interface EncryptedPayload {
  ciphertext: string    // Base64-encoded encrypted data
  iv: string            // Base64-encoded initialization vector (96-bit for GCM)
  ephemeralPublicKey: string  // Base64-encoded sender's ephemeral ECDH public key
  salt: string          // Base64-encoded HKDF salt
  algorithm: string     // e.g. "ECDH-P521+HKDF-SHA512+AES-GCM-256"
  version: number       // Protocol version for future upgrades
  hmac?: string         // HMAC-SHA512 for message authentication (extra layer)
}

// ============================================
// Message Types
// ============================================

export type MessageStatus = 'sending' | 'sent' | 'delivered' | 'read' | 'failed'
export type MessageType = 'text' | 'image' | 'file' | 'voice' | 'system'

export interface Reaction {
  emoji: string
  userIds: string[]
}

export interface Message {
  id: string
  chatId: string
  senderId: string
  content: string           // Decrypted content (only in memory, never stored)
  encryptedPayload?: EncryptedPayload  // What's actually stored/transmitted
  type: MessageType
  status: MessageStatus
  timestamp: Date
  editedAt?: Date
  replyToId?: string
  replyTo?: Message
  reactions: Reaction[]
  selfDestructAt?: Date     // For secret chats
  isDeleted?: boolean
  deletedForEveryone?: boolean
  fileUrl?: string
  fileName?: string
  fileSize?: number
}

// ============================================
// Chat Types
// ============================================

export type ChatType = 'private' | 'group' | 'secret'

export interface Chat {
  id: string
  type: ChatType
  name?: string             // For groups
  avatar?: string           // For groups
  participants: string[]    // User IDs
  participantDetails?: KUser[]
  lastMessage?: Message
  unreadCount: number
  createdAt: Date
  updatedAt: Date
  encryptionKey?: string    // Serialized shared key for group chats
  secretChatConfig?: SecretChatConfig
  typingUsers?: string[]    // User IDs currently typing
  isEncrypted: boolean
  pinnedMessageId?: string
  description?: string
}

export interface SecretChatConfig {
  selfDestructDuration: number  // In seconds (60 to 86400)
  selfDestructLabel: string     // "1 min", "1 hour", etc.
  encryptionLevel: 'standard' | 'paranoid'
}

// ============================================
// Store Types
// ============================================

export interface ChatStore {
  // State
  currentUser: KUser | null
  chats: Chat[]
  messages: Record<string, Message[]>  // chatId -> messages
  activeChat: string | null
  activeChatData: Chat | null
  typingIndicators: Record<string, string[]>
  onlineUsers: Set<string>
  searchQuery: string
  sidebarOpen: boolean
  
  // Encryption state
  keyPairs: Record<string, SerializedKeyPair>  // chatId -> key pair
  peerPublicKeys: Record<string, string>       // userId -> serialized public key

  // Actions
  setCurrentUser: (user: KUser) => void
  setActiveChat: (chatId: string | null) => void
  sendMessage: (chatId: string, content: string, replyToId?: string) => Promise<void>
  addReaction: (chatId: string, messageId: string, emoji: string) => void
  deleteMessage: (chatId: string, messageId: string, forEveryone: boolean) => void
  setTyping: (chatId: string, userId: string, isTyping: boolean) => void
  markAsRead: (chatId: string) => void
  createPrivateChat: (participant: KUser) => Promise<string>
  createGroupChat: (name: string, participants: KUser[]) => Promise<string>
  createSecretChat: (participant: KUser, config: SecretChatConfig) => Promise<string>
  setSearchQuery: (q: string) => void
  toggleSidebar: () => void
  initEncryption: (chatId: string) => Promise<void>
  loadInitialData: () => void
}
