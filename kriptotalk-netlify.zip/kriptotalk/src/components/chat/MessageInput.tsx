'use client'

import { useState, useRef, useCallback, useEffect } from 'react'
import {
  Send, Smile, Paperclip, Mic, Lock, Flame, X
} from 'lucide-react'
import { useChatStore } from '@/lib/store/chatStore'
import { cn } from '@/lib/utils'

interface Props {
  chatId: string
  chatType: 'private' | 'group' | 'secret'
}

const EMOJI_GRID = [
  '😀','😂','🥰','😍','🤔','😅','😭','😤',
  '👍','👎','❤️','🔥','🎉','🚀','💯','✅',
  '🔐','🛡️','⚡','💎','🤝','👏','🙏','💪',
  '😈','🤖','👻','🦊','🐱','🎯','🌟','💫',
]

export function MessageInput({ chatId, chatType }: Props) {
  const { sendMessage, setTyping, currentUser, messages, activeChatData } = useChatStore()
  const [text, setText] = useState('')
  const [showEmoji, setShowEmoji] = useState(false)
  const [replyTo, setReplyTo] = useState<string | null>(null)
  const [isRecording, setIsRecording] = useState(false)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const isSecret = chatType === 'secret'

  const replyMessage = replyTo
    ? messages[chatId]?.find(m => m.id === replyTo)
    : null

  // Auto-resize textarea
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.style.height = 'auto'
      inputRef.current.style.height = Math.min(inputRef.current.scrollHeight, 120) + 'px'
    }
  }, [text])

  const handleTyping = useCallback(() => {
    if (!currentUser) return
    setTyping(chatId, currentUser.id, true)

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current)
    typingTimeoutRef.current = setTimeout(() => {
      setTyping(chatId, currentUser.id, false)
    }, 2000)
  }, [chatId, currentUser, setTyping])

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value)
    if (e.target.value) handleTyping()
  }

  const handleSend = async () => {
    const content = text.trim()
    if (!content) return

    setText('')
    setShowEmoji(false)
    setReplyTo(null)

    // Clear typing
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current)
    if (currentUser) setTyping(chatId, currentUser.id, false)

    await sendMessage(chatId, content, replyTo || undefined)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const addEmoji = (emoji: string) => {
    setText(prev => prev + emoji)
    inputRef.current?.focus()
  }

  const simulateVoice = () => {
    setIsRecording(true)
    setTimeout(() => {
      setIsRecording(false)
      sendMessage(chatId, '🎤 [Voice message - 0:12]')
    }, 2000)
  }

  return (
    <div className={cn(
      'flex-shrink-0 border-t bg-bg-secondary px-4 py-3',
      isSecret ? 'border-red-500/20' : 'border-border-primary'
    )}>
      {/* Reply preview */}
      {replyMessage && (
        <div className="flex items-center gap-2 mb-2 px-3 py-2 bg-bg-tertiary rounded-xl border-l-2 border-accent-primary">
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-accent-primary">Balas</p>
            <p className="text-xs text-text-muted truncate">{replyMessage.content}</p>
          </div>
          <button onClick={() => setReplyTo(null)} className="p-1 hover:bg-bg-hover rounded-lg">
            <X className="w-3.5 h-3.5 text-text-muted" />
          </button>
        </div>
      )}

      {/* Encryption status bar */}
      <div className="flex items-center gap-1.5 mb-2">
        {isSecret ? (
          <>
            <Flame className="w-3 h-3 text-red-400" />
            <span className="text-xs font-mono text-red-400">
              Secret · Self-destruct {activeChatData?.secretChatConfig?.selfDestructLabel}
            </span>
          </>
        ) : (
          <>
            <Lock className="w-3 h-3 text-accent-primary/60" />
            <span className="text-xs font-mono text-accent-primary/60">
              Terenkripsi E2E · ECDH-P521
            </span>
          </>
        )}
      </div>

      {/* Input row */}
      <div className="flex items-end gap-2">
        {/* Emoji & Attach */}
        <div className="flex gap-1 pb-1">
          <div className="relative">
            <button
              onClick={() => setShowEmoji(!showEmoji)}
              className={cn(
                'p-2 rounded-xl transition-colors',
                showEmoji
                  ? 'bg-accent-primary/10 text-accent-primary'
                  : 'text-text-muted hover:text-text-secondary hover:bg-bg-hover'
              )}
            >
              <Smile className="w-5 h-5" />
            </button>

            {/* Emoji picker */}
            {showEmoji && (
              <div className="absolute bottom-full mb-2 left-0 w-64 bg-bg-card border border-border-primary rounded-2xl p-3 shadow-card z-20 animate-slide-up">
                <p className="text-xs text-text-muted mb-2 font-mono">Pilih Emoji</p>
                <div className="grid grid-cols-8 gap-1">
                  {EMOJI_GRID.map(emoji => (
                    <button
                      key={emoji}
                      onClick={() => addEmoji(emoji)}
                      className="text-xl hover:scale-125 transition-transform p-0.5 rounded"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <button className="p-2 text-text-muted hover:text-text-secondary hover:bg-bg-hover rounded-xl transition-colors">
            <Paperclip className="w-5 h-5" />
          </button>
        </div>

        {/* Text input */}
        <div className={cn(
          'flex-1 bg-bg-input border rounded-2xl px-4 py-2.5 transition-all',
          isSecret
            ? 'border-red-500/20 focus-within:border-red-500/50'
            : 'border-border-secondary focus-within:border-accent-primary/50'
        )}>
          <textarea
            ref={inputRef}
            value={text}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
            placeholder={isSecret ? '🔴 Pesan rahasia...' : 'Pesan terenkripsi...'}
            rows={1}
            className="w-full bg-transparent text-sm text-text-primary placeholder-text-muted resize-none focus:outline-none leading-relaxed"
            style={{ maxHeight: '120px', overflowY: 'auto' }}
          />
        </div>

        {/* Send / Voice */}
        {text.trim() ? (
          <button
            onClick={handleSend}
            className={cn(
              'flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95',
              isSecret
                ? 'bg-red-600 hover:bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.3)]'
                : 'bg-accent-primary hover:brightness-110 shadow-[0_0_15px_rgba(0,212,255,0.3)]'
            )}
          >
            <Send className="w-4 h-4 text-bg-primary" />
          </button>
        ) : (
          <button
            onClick={simulateVoice}
            disabled={isRecording}
            className={cn(
              'flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center transition-all',
              isRecording
                ? 'bg-red-500 animate-pulse'
                : 'text-text-muted hover:text-text-secondary hover:bg-bg-hover'
            )}
          >
            <Mic className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Overlay to close emoji */}
      {showEmoji && (
        <div className="fixed inset-0 z-10" onClick={() => setShowEmoji(false)} />
      )}
    </div>
  )
}
