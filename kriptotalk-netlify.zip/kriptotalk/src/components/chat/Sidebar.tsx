'use client'

import { useState, useMemo } from 'react'
import { useSession, signOut } from 'next-auth/react'
import Image from 'next/image'
import {
  Search, Plus, Settings, LogOut, Shield, Lock,
  Users, MessageSquare, ChevronDown, X, Flame
} from 'lucide-react'
import { useChatStore, MOCK_USERS } from '@/lib/store/chatStore'
import { ChatListItem } from './ChatListItem'
import { NewChatModal } from './NewChatModal'
import { cn, formatChatListTime } from '@/lib/utils'
import type { Chat } from '@/types'

export function Sidebar() {
  const { data: session } = useSession()
  const {
    chats, searchQuery, setSearchQuery, activeChat,
    setActiveChat, currentUser, onlineUsers
  } = useChatStore()
  const [showNewChat, setShowNewChat] = useState(false)
  const [showUserMenu, setShowUserMenu] = useState(false)

  // Filter chats based on search
  const filteredChats = useMemo(() => {
    if (!searchQuery.trim()) return chats.sort((a, b) =>
      new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    )
    const q = searchQuery.toLowerCase()
    return chats.filter(chat => {
      const name = getChatDisplayName(chat, currentUser?.id || '')
      return name.toLowerCase().includes(q)
    }).sort((a, b) =>
      new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    )
  }, [chats, searchQuery, currentUser])

  const totalUnread = chats.reduce((sum, c) => sum + c.unreadCount, 0)

  return (
    <div className="h-full flex flex-col bg-bg-secondary border-r border-border-primary">
      {/* Header */}
      <div className="flex-shrink-0 px-4 py-3 border-b border-border-primary bg-bg-tertiary">
        {/* App logo + user */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Shield className="w-6 h-6 text-accent-primary" strokeWidth={1.5} />
              <div className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-status-online" />
            </div>
            <div>
              <span className="font-bold text-text-primary text-base gradient-text">KriptoTalk</span>
              {totalUnread > 0 && (
                <span className="ml-2 text-xs bg-accent-primary text-bg-primary font-bold px-1.5 py-0.5 rounded-full">
                  {totalUnread}
                </span>
              )}
            </div>
          </div>

          {/* User avatar */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 hover:bg-bg-hover rounded-xl p-1.5 transition-colors"
            >
              <div className="relative">
                {session?.user?.image ? (
                  <Image
                    src={session.user.image}
                    alt="Avatar"
                    width={32}
                    height={32}
                    className="rounded-full border-2 border-accent-primary/30"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-accent-primary/20 border-2 border-accent-primary/30 flex items-center justify-center text-accent-primary text-sm font-bold">
                    {session?.user?.name?.[0] || 'U'}
                  </div>
                )}
                <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-status-online border-2 border-bg-tertiary" />
              </div>
              <ChevronDown className={cn(
                "w-3.5 h-3.5 text-text-muted transition-transform",
                showUserMenu && "rotate-180"
              )} />
            </button>

            {/* User dropdown */}
            {showUserMenu && (
              <div className="absolute right-0 top-full mt-1 w-52 glass border border-border-primary rounded-xl shadow-card z-50 overflow-hidden animate-slide-up">
                <div className="p-3 border-b border-border-secondary">
                  <p className="text-sm font-semibold text-text-primary truncate">{session?.user?.name}</p>
                  <p className="text-xs text-text-muted truncate">{session?.user?.email}</p>
                  <div className="flex items-center gap-1 mt-1.5">
                    <Lock className="w-3 h-3 text-accent-primary" />
                    <span className="text-xs text-accent-primary font-mono">E2E Encrypted</span>
                  </div>
                </div>
                <button
                  onClick={() => signOut({ callbackUrl: '/login' })}
                  className="w-full flex items-center gap-2.5 px-3 py-2.5 text-sm text-red-400 hover:bg-red-500/10 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Cari pesan atau kontak..."
            className="w-full bg-bg-input border border-border-secondary rounded-xl pl-9 pr-9 py-2.5 text-sm text-text-primary placeholder-text-muted focus:outline-none focus:border-accent-primary/50 focus:bg-bg-card transition-all"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2">
              <X className="w-3.5 h-3.5 text-text-muted hover:text-text-secondary" />
            </button>
          )}
        </div>
      </div>

      {/* Cipher suite info */}
      <div className="flex-shrink-0 mx-3 mt-2 mb-1">
        <div className="flex items-center gap-1.5 bg-accent-primary/5 border border-accent-primary/20 rounded-lg px-2.5 py-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-status-online animate-pulse" />
          <span className="text-xs font-mono text-accent-primary/80">ECDH-P521 + AES-256-GCM aktif</span>
        </div>
      </div>

      {/* Chat list */}
      <div className="flex-1 overflow-y-auto py-1">
        {filteredChats.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-6">
            <MessageSquare className="w-12 h-12 text-text-muted mb-3 opacity-50" />
            <p className="text-text-secondary text-sm">
              {searchQuery ? 'Tidak ada chat ditemukan' : 'Belum ada chat'}
            </p>
            {!searchQuery && (
              <button
                onClick={() => setShowNewChat(true)}
                className="mt-3 text-xs text-accent-primary hover:underline"
              >
                Mulai chat baru
              </button>
            )}
          </div>
        ) : (
          filteredChats.map(chat => (
            <ChatListItem
              key={chat.id}
              chat={chat}
              isActive={chat.id === activeChat}
              onClick={() => setActiveChat(chat.id)}
              currentUserId={currentUser?.id || ''}
              onlineUsers={onlineUsers}
            />
          ))
        )}
      </div>

      {/* New Chat Button */}
      <div className="flex-shrink-0 p-3 border-t border-border-primary">
        <button
          onClick={() => setShowNewChat(true)}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-medium text-sm transition-all duration-200"
          style={{
            background: 'linear-gradient(135deg, #0d3464, #1a1a3e)',
            border: '1px solid #00d4ff33',
            boxShadow: '0 0 15px #00d4ff11',
          }}
        >
          <Plus className="w-4 h-4 text-accent-primary" />
          <span className="text-text-primary">Chat Baru</span>
        </button>
      </div>

      {/* New Chat Modal */}
      {showNewChat && (
        <NewChatModal onClose={() => setShowNewChat(false)} />
      )}

      {/* Overlay for user menu */}
      {showUserMenu && (
        <div className="fixed inset-0 z-40" onClick={() => setShowUserMenu(false)} />
      )}
    </div>
  )
}

function getChatDisplayName(chat: Chat, currentUserId: string): string {
  if (chat.type === 'group' || chat.type === 'group') return chat.name || 'Group'
  const other = chat.participantDetails?.find(p => p.id !== currentUserId)
  return other?.name || 'Unknown'
}
