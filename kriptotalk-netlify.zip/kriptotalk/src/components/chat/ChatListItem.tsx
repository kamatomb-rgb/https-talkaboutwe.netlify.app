'use client'

import Image from 'next/image'
import { Lock, Flame, Users, Shield } from 'lucide-react'
import { cn, formatChatListTime, getInitials, truncate } from '@/lib/utils'
import type { Chat, KUser } from '@/types'

interface Props {
  chat: Chat
  isActive: boolean
  onClick: () => void
  currentUserId: string
  onlineUsers: Set<string>
}

export function ChatListItem({ chat, isActive, onClick, currentUserId, onlineUsers }: Props) {
  const otherUser = chat.participantDetails?.find(p => p.id !== currentUserId)
  const isGroup = chat.type === 'group'
  const isSecret = chat.type === 'secret'

  const displayName = isGroup ? (chat.name || 'Group') : (otherUser?.name || 'Unknown')
  const avatar = isGroup ? chat.avatar : otherUser?.avatar
  const isOnline = !isGroup && otherUser ? onlineUsers.has(otherUser.id) : false

  const lastMsgContent = chat.lastMessage?.content || ''
  const lastMsgTime = chat.lastMessage?.timestamp
  const isMine = chat.lastMessage?.senderId === currentUserId

  return (
    <button
      onClick={onClick}
      className={cn(
        'chat-item w-full flex items-center gap-3 px-3 py-3 text-left border-l-2 transition-all',
        isActive
          ? 'chat-item-active'
          : 'border-transparent hover:bg-bg-hover'
      )}
    >
      {/* Avatar */}
      <div className="relative flex-shrink-0">
        <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-border-primary">
          {avatar ? (
            <Image src={avatar} alt={displayName} width={48} height={48} className="object-cover" />
          ) : (
            <div className="w-full h-full bg-accent-primary/20 flex items-center justify-center text-accent-primary font-bold text-base">
              {getInitials(displayName)}
            </div>
          )}
        </div>
        {/* Online indicator */}
        {isOnline && !isGroup && (
          <div className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-status-online border-2 border-bg-secondary" />
        )}
        {/* Group icon */}
        {isGroup && (
          <div className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-accent-purple border-2 border-bg-secondary flex items-center justify-center">
            <Users className="w-2 h-2 text-white" />
          </div>
        )}
        {/* Secret chat icon */}
        {isSecret && (
          <div className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-red-500 border-2 border-bg-secondary flex items-center justify-center">
            <Flame className="w-2 h-2 text-white" />
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-0.5">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className={cn(
              "font-semibold text-sm truncate",
              isActive ? 'text-white' : 'text-text-primary'
            )}>
              {displayName}
            </span>
            {/* Encryption badge */}
            {isSecret ? (
              <Flame className="w-3 h-3 text-red-400 flex-shrink-0" />
            ) : (
              <Lock className="w-2.5 h-2.5 text-accent-primary/60 flex-shrink-0" />
            )}
          </div>
          <div className="flex flex-col items-end gap-1 flex-shrink-0 ml-1">
            {lastMsgTime && (
              <span className="text-[10px] text-text-muted">
                {formatChatListTime(new Date(lastMsgTime))}
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center justify-between gap-1">
          <p className="text-xs text-text-secondary truncate flex-1">
            {isMine && <span className="text-accent-primary/60 mr-1">Kamu:</span>}
            {truncate(lastMsgContent, 38)}
          </p>
          {chat.unreadCount > 0 && (
            <span className="flex-shrink-0 min-w-[18px] h-[18px] rounded-full bg-accent-primary text-bg-primary text-[10px] font-bold flex items-center justify-center px-1">
              {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
            </span>
          )}
        </div>
      </div>
    </button>
  )
}
