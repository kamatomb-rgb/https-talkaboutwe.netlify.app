'use client'

import Image from 'next/image'
import { getInitials } from '@/lib/utils'
import type { KUser } from '@/types'

interface TypingProps {
  typingUserIds: string[]
  participants: KUser[]
  currentUserId: string
}

export function TypingIndicator({ typingUserIds, participants, currentUserId }: TypingProps) {
  const typingUsers = participants.filter(
    p => typingUserIds.includes(p.id) && p.id !== currentUserId
  )
  if (typingUsers.length === 0) return null

  const label = typingUsers.length === 1
    ? `${typingUsers[0].name.split(' ')[0]} sedang mengetik`
    : `${typingUsers.length} orang sedang mengetik`

  return (
    <div className="flex items-end gap-2 mb-1 animate-fade-in">
      <div className="w-7 flex-shrink-0">
        {typingUsers[0].avatar && (
          <Image
            src={typingUsers[0].avatar}
            alt={typingUsers[0].name}
            width={28}
            height={28}
            className="rounded-full border border-border-primary"
          />
        )}
      </div>
      <div className="bg-bubble-received border border-bubble-receivedBorder rounded-2xl rounded-bl-sm px-4 py-2.5 flex items-center gap-2">
        <div className="flex gap-1">
          <span className="typing-dot" />
          <span className="typing-dot" />
          <span className="typing-dot" />
        </div>
        <span className="text-xs text-text-muted ml-1">{label}</span>
      </div>
    </div>
  )
}
