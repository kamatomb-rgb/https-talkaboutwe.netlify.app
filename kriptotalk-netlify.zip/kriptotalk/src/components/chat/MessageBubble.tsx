'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { Check, CheckCheck, Clock, Trash2, CornerUpLeft, Smile, Timer } from 'lucide-react'
import { useChatStore } from '@/lib/store/chatStore'
import { cn, formatMessageTime, getInitials, EMOJI_REACTIONS } from '@/lib/utils'
import type { Message, KUser } from '@/types'

interface Props {
  message: Message
  isMine: boolean
  sender?: KUser
  chatId: string
  showAvatar: boolean
  showName: boolean
  isLast: boolean
  allMessages: Message[]
}

export function MessageBubble({ message, isMine, sender, chatId, showAvatar, showName, isLast, allMessages }: Props) {
  const { addReaction, deleteMessage, sendMessage, activeChatData } = useChatStore()
  const [showActions, setShowActions] = useState(false)
  const [showReactions, setShowReactions] = useState(false)
  const [timeLeft, setTimeLeft] = useState<string | null>(null)

  // Self-destruct countdown
  useEffect(() => {
    if (!message.selfDestructAt || message.isDeleted) return

    const update = () => {
      const remaining = new Date(message.selfDestructAt!).getTime() - Date.now()
      if (remaining <= 0) {
        setTimeLeft(null)
        return
      }
      const seconds = Math.floor(remaining / 1000)
      const mins = Math.floor(seconds / 60)
      const secs = seconds % 60
      setTimeLeft(mins > 0 ? `${mins}m ${secs}s` : `${secs}s`)
    }

    update()
    const interval = setInterval(update, 1000)
    return () => clearInterval(interval)
  }, [message.selfDestructAt, message.isDeleted])

  const isDeleted = message.isDeleted

  const replyMsg = message.replyToId
    ? allMessages.find(m => m.id === message.replyToId)
    : message.replyTo

  const totalReactions = message.reactions.reduce((sum, r) => sum + r.userIds.length, 0)
  const isSecret = activeChatData?.type === 'secret'

  return (
    <div
      className={cn(
        'group flex items-end gap-2 mb-1 relative',
        isMine ? 'flex-row-reverse' : 'flex-row'
      )}
      onMouseEnter={() => !isDeleted && setShowActions(true)}
      onMouseLeave={() => { setShowActions(false); setShowReactions(false) }}
    >
      {/* Avatar (for received messages) */}
      <div className="w-7 flex-shrink-0">
        {showAvatar && !isMine && sender && (
          <div className="w-7 h-7 rounded-full overflow-hidden border border-border-primary">
            {sender.avatar ? (
              <Image src={sender.avatar} alt={sender.name} width={28} height={28} className="object-cover" />
            ) : (
              <div className="w-full h-full bg-accent-primary/20 flex items-center justify-center text-accent-primary text-xs font-bold">
                {getInitials(sender.name)}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Message content */}
      <div className={cn('flex flex-col max-w-[70%]', isMine ? 'items-end' : 'items-start')}>
        {/* Sender name for groups */}
        {showName && sender && !isMine && (
          <span className="text-xs font-semibold mb-1 ml-3" style={{ color: stringToColor(sender.id) }}>
            {sender.name}
          </span>
        )}

        {/* Reply preview */}
        {replyMsg && !isDeleted && (
          <div className={cn(
            'flex items-center gap-2 rounded-lg px-3 py-1.5 mb-1 border-l-2 border-accent-primary max-w-full',
            isMine ? 'bg-bubble-sent/50' : 'bg-bg-card/80'
          )}>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-accent-primary truncate">
                {replyMsg.senderId === 'me' ? 'Kamu' : sender?.name || 'User'}
              </p>
              <p className="text-xs text-text-muted truncate">{replyMsg.content}</p>
            </div>
          </div>
        )}

        {/* Bubble */}
        <div className={cn(
          'relative px-4 py-2.5 rounded-2xl shadow-bubble max-w-full break-words',
          isMine ? 'message-bubble-sent' : 'message-bubble-received',
          isMine
            ? isSecret
              ? 'bg-red-900/40 border border-red-500/30 rounded-br-sm'
              : 'bg-bubble-sent border border-bubble-sentBorder rounded-br-sm'
            : 'bg-bubble-received border border-bubble-receivedBorder rounded-bl-sm',
          isDeleted && 'opacity-60'
        )}>
          {isDeleted ? (
            <p className="text-sm italic text-text-muted">{message.content}</p>
          ) : (
            <>
              <p className="text-sm text-text-primary leading-relaxed whitespace-pre-wrap">
                {message.content}
              </p>

              {/* Self-destruct timer */}
              {timeLeft && (
                <div className="flex items-center gap-1 mt-1.5">
                  <Timer className="w-3 h-3 text-red-400" />
                  <span className="text-xs font-mono text-red-400">{timeLeft}</span>
                  <div
                    className="self-destruct-timer flex-1"
                    style={{
                      animation: `countdown ${(new Date(message.selfDestructAt!).getTime() - Date.now()) / 1000}s linear forwards`,
                    }}
                  />
                </div>
              )}
            </>
          )}

          {/* Timestamp + status */}
          <div className={cn('flex items-center gap-1 mt-1', isMine ? 'justify-end' : 'justify-start')}>
            <span className="text-[10px] text-text-muted">
              {formatMessageTime(new Date(message.timestamp))}
              {message.editedAt && <span className="ml-1">(edit)</span>}
            </span>
            {isMine && !isDeleted && (
              <StatusIcon status={message.status} />
            )}
          </div>
        </div>

        {/* Reactions display */}
        {message.reactions.length > 0 && !isDeleted && (
          <div className={cn('flex flex-wrap gap-1 mt-1', isMine ? 'justify-end' : 'justify-start')}>
            {message.reactions.filter(r => r.userIds.length > 0).map(reaction => (
              <button
                key={reaction.emoji}
                onClick={() => addReaction(chatId, message.id, reaction.emoji)}
                className="flex items-center gap-1 bg-bg-card border border-border-primary rounded-full px-2 py-0.5 text-xs hover:bg-bg-hover transition-colors"
              >
                <span>{reaction.emoji}</span>
                <span className="text-text-secondary">{reaction.userIds.length}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Action buttons (hover) */}
      {showActions && !isDeleted && (
        <div className={cn(
          'flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity self-center',
          isMine ? 'flex-row-reverse mr-1' : 'ml-1'
        )}>
          {/* Emoji reaction */}
          <div className="relative">
            <button
              onClick={() => setShowReactions(!showReactions)}
              className="p-1.5 hover:bg-bg-hover rounded-lg text-text-muted hover:text-text-secondary transition-colors"
            >
              <Smile className="w-4 h-4" />
            </button>

            {showReactions && (
              <div className={cn(
                'absolute bottom-full mb-1 bg-bg-card border border-border-primary rounded-2xl p-2 flex gap-1.5 shadow-card z-10 animate-slide-up',
                isMine ? 'right-0' : 'left-0'
              )}>
                {EMOJI_REACTIONS.map(emoji => (
                  <button
                    key={emoji}
                    onClick={() => { addReaction(chatId, message.id, emoji); setShowReactions(false) }}
                    className="text-lg hover:scale-125 transition-transform"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Reply */}
          <button
            onClick={() => {/* handled by input */}}
            className="p-1.5 hover:bg-bg-hover rounded-lg text-text-muted hover:text-text-secondary transition-colors"
            title="Reply"
          >
            <CornerUpLeft className="w-4 h-4" />
          </button>

          {/* Delete (secret chats only, own messages) */}
          {isMine && isSecret && (
            <button
              onClick={() => deleteMessage(chatId, message.id, true)}
              className="p-1.5 hover:bg-red-500/10 rounded-lg text-text-muted hover:text-red-400 transition-colors"
              title="Hapus untuk semua"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      )}
    </div>
  )
}

function StatusIcon({ status }: { status: Message['status'] }) {
  if (status === 'sending') return <Clock className="w-3 h-3 text-text-muted" />
  if (status === 'sent') return <Check className="w-3 h-3 text-text-muted" />
  if (status === 'delivered') return <CheckCheck className="w-3 h-3 text-text-muted" />
  if (status === 'read') return <CheckCheck className="w-3 h-3 text-accent-primary" />
  return null
}

// Generate consistent color from string (for group member names)
function stringToColor(str: string): string {
  const colors = [
    '#00d4ff', '#7b2fff', '#00e676', '#ffd54f',
    '#ff7043', '#26c6da', '#ab47bc', '#66bb6a'
  ]
  let hash = 0
  for (let i = 0; i < str.length; i++) hash = str.charCodeAt(i) + ((hash << 5) - hash)
  return colors[Math.abs(hash) % colors.length]
}
