'use client'

import { useState } from 'react'
import Image from 'next/image'
import { X, Lock, Flame, Users, Search, ChevronRight, Timer } from 'lucide-react'
import { useChatStore, MOCK_USERS } from '@/lib/store/chatStore'
import { cn, SELF_DESTRUCT_OPTIONS, getInitials } from '@/lib/utils'
import type { KUser, SecretChatConfig } from '@/types'

interface Props {
  onClose: () => void
}

type ModalStep = 'choose' | 'private' | 'group' | 'secret'

export function NewChatModal({ onClose }: Props) {
  const { createPrivateChat, createGroupChat, createSecretChat, setActiveChat, currentUser, onlineUsers } = useChatStore()
  const [step, setStep] = useState<ModalStep>('choose')
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<KUser[]>([])
  const [groupName, setGroupName] = useState('')
  const [selfDestructDuration, setSelfDestructDuration] = useState(300)
  const [loading, setLoading] = useState(false)

  const availableUsers = MOCK_USERS.filter(u =>
    u.id !== currentUser?.id &&
    (u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase()))
  )

  const handleCreatePrivate = async (user: KUser) => {
    setLoading(true)
    const chatId = await createPrivateChat(user)
    setActiveChat(chatId)
    onClose()
  }

  const handleCreateGroup = async () => {
    if (!groupName.trim() || selected.length < 1) return
    setLoading(true)
    const chatId = await createGroupChat(groupName, selected)
    setActiveChat(chatId)
    onClose()
  }

  const handleCreateSecret = async (user: KUser) => {
    const option = SELF_DESTRUCT_OPTIONS.find(o => o.value === selfDestructDuration)!
    const config: SecretChatConfig = {
      selfDestructDuration,
      selfDestructLabel: option.label,
      encryptionLevel: 'paranoid',
    }
    setLoading(true)
    const chatId = await createSecretChat(user, config)
    setActiveChat(chatId)
    onClose()
  }

  const toggleSelect = (user: KUser) => {
    setSelected(prev =>
      prev.find(u => u.id === user.id)
        ? prev.filter(u => u.id !== user.id)
        : prev.length < 9 ? [...prev, user] : prev
    )
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full max-w-md glass border border-border-primary rounded-2xl shadow-card overflow-hidden animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border-secondary">
          <div className="flex items-center gap-2">
            {step !== 'choose' && (
              <button onClick={() => setStep('choose')} className="text-text-muted hover:text-text-primary mr-1">
                ←
              </button>
            )}
            <h2 className="font-bold text-text-primary">
              {step === 'choose' && 'Chat Baru'}
              {step === 'private' && 'Private Chat'}
              {step === 'group' && 'Buat Grup'}
              {step === 'secret' && '🔴 Secret Chat'}
            </h2>
          </div>
          <button onClick={onClose} className="text-text-muted hover:text-text-primary p-1.5 hover:bg-bg-hover rounded-lg">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Choose type */}
        {step === 'choose' && (
          <div className="p-4 space-y-2">
            {[
              {
                type: 'private' as const,
                icon: Lock,
                label: 'Private Chat',
                desc: 'Chat 1-on-1 dengan enkripsi E2E',
                color: 'text-accent-primary',
                bg: 'bg-accent-primary/10',
              },
              {
                type: 'group' as const,
                icon: Users,
                label: 'Group Chat',
                desc: 'Hingga 10 orang, dienkripsi',
                color: 'text-accent-purple',
                bg: 'bg-accent-purple/10',
              },
              {
                type: 'secret' as const,
                icon: Flame,
                label: 'Secret Chat',
                desc: 'Self-destruct + enkripsi paranoid',
                color: 'text-red-400',
                bg: 'bg-red-500/10',
              },
            ].map(item => (
              <button
                key={item.type}
                onClick={() => setStep(item.type)}
                className="w-full flex items-center gap-3 p-3.5 rounded-xl bg-bg-tertiary hover:bg-bg-hover border border-border-secondary hover:border-border-primary transition-all text-left"
              >
                <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center', item.bg)}>
                  <item.icon className={cn('w-5 h-5', item.color)} />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-sm text-text-primary">{item.label}</p>
                  <p className="text-xs text-text-muted">{item.desc}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-text-muted" />
              </button>
            ))}
          </div>
        )}

        {/* Private / Secret — pick a user */}
        {(step === 'private' || step === 'secret') && (
          <div>
            {/* Secret chat settings */}
            {step === 'secret' && (
              <div className="px-4 pt-4 pb-2">
                <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Timer className="w-4 h-4 text-red-400" />
                    <span className="text-sm font-semibold text-red-400">Self-Destruct Timer</span>
                  </div>
                  <div className="grid grid-cols-5 gap-1">
                    {SELF_DESTRUCT_OPTIONS.map(opt => (
                      <button
                        key={opt.value}
                        onClick={() => setSelfDestructDuration(opt.value)}
                        className={cn(
                          'text-xs py-1.5 rounded-lg border transition-all font-mono',
                          selfDestructDuration === opt.value
                            ? 'bg-red-500/30 border-red-500/60 text-red-300'
                            : 'bg-bg-tertiary border-border-secondary text-text-muted'
                        )}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Search */}
            <div className="px-4 py-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
                <input
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Cari kontak..."
                  className="w-full bg-bg-input border border-border-secondary rounded-xl pl-9 pr-3 py-2 text-sm text-text-primary placeholder-text-muted focus:outline-none focus:border-accent-primary/50 transition-all"
                />
              </div>
            </div>

            {/* User list */}
            <div className="max-h-72 overflow-y-auto px-4 pb-4 space-y-1">
              {availableUsers.map(user => (
                <button
                  key={user.id}
                  onClick={() => step === 'private' ? handleCreatePrivate(user) : handleCreateSecret(user)}
                  disabled={loading}
                  className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-bg-hover border border-transparent hover:border-border-secondary transition-all"
                >
                  <div className="relative">
                    <Image src={user.avatar} alt={user.name} width={40} height={40} className="rounded-full" />
                    {onlineUsers.has(user.id) && (
                      <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-status-online border-2 border-bg-secondary" />
                    )}
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-semibold text-text-primary">{user.name}</p>
                    <p className="text-xs text-text-muted">{onlineUsers.has(user.id) ? '🟢 Online' : '⚫ Offline'}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-text-muted" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Group chat */}
        {step === 'group' && (
          <div className="p-4 space-y-3">
            <input
              value={groupName}
              onChange={e => setGroupName(e.target.value)}
              placeholder="Nama grup..."
              className="w-full bg-bg-input border border-border-secondary rounded-xl px-4 py-2.5 text-sm text-text-primary placeholder-text-muted focus:outline-none focus:border-accent-primary/50 transition-all"
            />

            {selected.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {selected.map(u => (
                  <div key={u.id} className="flex items-center gap-1.5 bg-accent-primary/15 border border-accent-primary/30 rounded-full px-2.5 py-1">
                    <span className="text-xs text-accent-primary">{u.name.split(' ')[0]}</span>
                    <button onClick={() => toggleSelect(u)}>
                      <X className="w-3 h-3 text-accent-primary" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="max-h-52 overflow-y-auto space-y-1">
              {availableUsers.map(user => {
                const isSelected = selected.find(u => u.id === user.id)
                return (
                  <button
                    key={user.id}
                    onClick={() => toggleSelect(user)}
                    className={cn(
                      'w-full flex items-center gap-3 p-2.5 rounded-xl border transition-all',
                      isSelected
                        ? 'bg-accent-primary/10 border-accent-primary/30'
                        : 'bg-bg-tertiary border-transparent hover:bg-bg-hover'
                    )}
                  >
                    <Image src={user.avatar} alt={user.name} width={36} height={36} className="rounded-full" />
                    <span className="text-sm text-text-primary flex-1 text-left">{user.name}</span>
                    {isSelected && <div className="w-5 h-5 rounded-full bg-accent-primary flex items-center justify-center text-bg-primary text-xs">✓</div>}
                  </button>
                )
              })}
            </div>

            <button
              onClick={handleCreateGroup}
              disabled={!groupName.trim() || selected.length < 1 || loading}
              className="w-full py-2.5 rounded-xl font-semibold text-sm disabled:opacity-40 transition-all"
              style={{ background: 'linear-gradient(135deg, #0d3464, #1a1a3e)', border: '1px solid #00d4ff33' }}
            >
              {loading ? 'Membuat...' : `Buat Grup (${selected.length + 1} anggota)`}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
