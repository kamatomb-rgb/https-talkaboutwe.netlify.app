'use client'

import { Shield, Lock, Zap, Eye, Key, ChevronRight } from 'lucide-react'
import { useChatStore } from '@/lib/store/chatStore'

export function WelcomeScreen() {
  const { toggleSidebar } = useChatStore()

  const features = [
    {
      icon: Key,
      title: 'ECDH P-521',
      desc: 'Elliptic curve ~15,360-bit RSA equivalent',
      color: 'text-accent-primary',
      bg: 'bg-accent-primary/10',
    },
    {
      icon: Shield,
      title: 'AES-256-GCM',
      desc: 'Authenticated encryption per pesan',
      color: 'text-accent-purple',
      bg: 'bg-accent-purple/10',
    },
    {
      icon: Zap,
      title: 'HKDF-SHA512',
      desc: 'Key derivation dengan salt unik per pesan',
      color: 'text-status-online',
      bg: 'bg-status-online/10',
    },
    {
      icon: Eye,
      title: 'Zero-Knowledge',
      desc: 'Server hanya simpan ciphertext',
      color: 'text-yellow-400',
      bg: 'bg-yellow-400/10',
    },
  ]

  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-bg-primary relative overflow-hidden">
      {/* Background grid */}
      <div className="absolute inset-0 grid-bg opacity-30" />

      {/* Glow effects */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-96 h-96 bg-accent-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/3 left-1/3 w-64 h-64 bg-accent-secondary/5 rounded-full blur-3xl" />

      <div className="relative z-10 text-center px-8 max-w-lg">
        {/* Logo */}
        <div className="relative inline-flex items-center justify-center mb-8">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-bg-card to-bg-tertiary border border-border-glow flex items-center justify-center shadow-glow-cyan">
            <Shield className="w-12 h-12 text-accent-primary" strokeWidth={1.5} />
          </div>
          <div className="absolute inset-0 rounded-3xl border border-accent-primary/20 animate-spin" style={{ animationDuration: '10s' }} />
          <div className="absolute inset-[-6px] rounded-3xl border border-accent-secondary/10 animate-spin" style={{ animationDuration: '15s', animationDirection: 'reverse' }} />
        </div>

        <h1 className="text-3xl font-bold gradient-text mb-2">KriptoTalk</h1>
        <p className="text-text-muted text-sm font-mono mb-2">END-TO-END ENCRYPTED MESSENGER</p>
        <p className="text-text-secondary text-sm mb-8">
          Pilih chat dari sidebar atau mulai percakapan baru dengan keamanan tingkat militer.
        </p>

        {/* Feature grid */}
        <div className="grid grid-cols-2 gap-3 mb-8">
          {features.map(f => (
            <div
              key={f.title}
              className="flex items-start gap-3 p-3.5 rounded-xl bg-bg-card border border-border-secondary text-left"
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${f.bg}`}>
                <f.icon className={`w-4 h-4 ${f.color}`} />
              </div>
              <div>
                <p className="text-xs font-bold text-text-primary font-mono">{f.title}</p>
                <p className="text-xs text-text-muted leading-tight mt-0.5">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Cipher suite */}
        <div className="bg-bg-card border border-accent-primary/20 rounded-xl p-4 font-mono text-xs text-left">
          <p className="text-accent-primary mb-1 font-semibold">Active Cipher Suite:</p>
          <p className="text-text-secondary break-all">
            ECDH-P521 + HKDF-SHA512 + AES-256-GCM-128 + HMAC-SHA512
          </p>
          <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-border-secondary">
            <div className="w-2 h-2 rounded-full bg-status-online animate-pulse" />
            <span className="text-status-online text-xs">Forward Secrecy aktif · Per-message ephemeral keys</span>
          </div>
        </div>

        {/* Mobile sidebar trigger */}
        <button
          onClick={toggleSidebar}
          className="md:hidden mt-6 flex items-center gap-2 mx-auto px-5 py-2.5 rounded-xl text-sm font-medium"
          style={{ background: 'linear-gradient(135deg, #0d3464, #1a1a3e)', border: '1px solid #00d4ff33' }}
        >
          <Lock className="w-4 h-4 text-accent-primary" />
          <span className="text-text-primary">Buka Daftar Chat</span>
          <ChevronRight className="w-4 h-4 text-accent-primary" />
        </button>
      </div>
    </div>
  )
}
