'use client'

import { useState } from 'react'
import Image from 'next/image'
import {
  Lock, Flame, Users, MoreVertical, Search,
  Phone, Video, Shield, Key, ChevronLeft, Info
} from 'lucide-react'
import { useChatStore } from '@/lib/store/chatStore'
import { cn, formatLastSeen, getInitials } from '@/lib/utils'
import type { Chat } from '@/types'

interface Props {
  chat: Chat
  currentUserId: string
}

export function ChatHeader({ chat, currentUserId }: Props) {
  const { onlineUsers, toggleSidebar, setActiveChat, keyPairs } = useChatStore()
  const [showInfo, setShowInfo] = useState(false)

  const isGroup = chat.type === 'group'
  const isSecret = chat.type === 'secret'
  const otherUser = chat.participantDetails?.find(p => p.id !== currentUserId)

  const displayName = isGroup ? (chat.name || 'Group') : (otherUser?.name || 'Unknown')
  const avatar = isGroup ? chat.avatar : otherUser?.avatar
  const isOnline = !isGroup && otherUser ? onlineUsers.has(otherUser.id) : false

  const statusText = isGroup
    ? `${chat.participants.length} anggota`
    : isOnline
      ? '🟢 Online'
      : otherUser?.lastSeen
        ? formatLastSeen(new Date(otherUser.lastSeen))
        : '⚫ Offline'

  const chatKeyPair = keyPairs[chat.id]

  return (
    <>
      <div className="flex items-center gap-3 px-4 py-3 border-b border-border-primary bg-bg-secondary flex-shrink-0">
        {/* Mobile back button */}
        <button
          className="md:hidden p-1.5 hover:bg-bg-hover rounded-lg"
          onClick={() => setActiveChat(null)}
        >
          <ChevronLeft className="w-5 h-5 text-text-secondary" />
        </button>

        {/* Avatar */}
        <div className="relative flex-shrink-0 cursor-pointer" onClick={() => setShowInfo(!showInfo)}>
          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-border-primary">
            {avatar ? (
              <Image src={avatar} alt={displayName} width={40} height={40} className="object-cover" />
            ) : (
              <div className="w-full h-full bg-accent-primary/20 flex items-center justify-center text-accent-primary font-bold">
                {getInitials(displayName)}
              </div>
            )}
          </div>
          {isOnline && !isGroup && (
            <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-status-online border-2 border-bg-secondary" />
          )}
        </div>

        {/* Name & status */}
        <div className="flex-1 min-w-0 cursor-pointer" onClick={() => setShowInfo(!showInfo)}>
          <div className="flex items-center gap-1.5">
            <h2 className="font-bold text-text-primary text-base truncate">{displayName}</h2>
            {isSecret && <Flame className="w-4 h-4 text-red-400 flex-shrink-0" />}
            {!isSecret && <Lock className="w-3 h-3 text-accent-primary/50 flex-shrink-0" />}
          </div>
          <p className="text-xs text-text-muted truncate">{statusText}</p>
        </div>

        {/* Encryption badge */}
        <div className={cn(
          "flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono border hidden sm:flex",
          isSecret
            ? 'bg-red-500/10 border-red-500/30 text-red-400'
            : 'bg-accent-primary/10 border-accent-primary/30 text-accent-primary'
        )}>
          {isSecret ? (
            <>
              <Flame className="w-3 h-3" />
              <span>PARANOID</span>
            </>
          ) : (
            <>
              <Shield className="w-3 h-3" />
              <span>E2E</span>
            </>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-1">
          <button className="p-2 hover:bg-bg-hover rounded-xl transition-colors text-text-muted hover:text-text-secondary">
            <Phone className="w-4.5 h-4.5 w-[18px] h-[18px]" />
          </button>
          <button className="p-2 hover:bg-bg-hover rounded-xl transition-colors text-text-muted hover:text-text-secondary">
            <Video className="w-[18px] h-[18px]" />
          </button>
          <button
            onClick={() => setShowInfo(!showInfo)}
            className={cn(
              "p-2 rounded-xl transition-colors",
              showInfo ? 'bg-accent-primary/10 text-accent-primary' : 'hover:bg-bg-hover text-text-muted hover:text-text-secondary'
            )}
          >
            <Info className="w-[18px] h-[18px]" />
          </button>
        </div>
      </div>

      {/* Encryption info panel */}
      {showInfo && (
        <div className="flex-shrink-0 px-4 py-3 bg-bg-tertiary border-b border-border-secondary animate-slide-up">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-accent-primary/10 flex items-center justify-center flex-shrink-0">
              <Key className="w-4 h-4 text-accent-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-text-primary mb-1">Enkripsi Aktif</p>
              <div className="space-y-0.5 text-xs font-mono text-text-muted">
                <p>Algoritma: <span className="text-accent-primary">ECDH P-521 + HKDF-SHA512</span></p>
                <p>Cipher: <span className="text-accent-primary">AES-256-GCM + HMAC-SHA512</span></p>
                <p>Forward Secrecy: <span className="text-status-online">Aktif (per pesan)</span></p>
                {chatKeyPair && (
                  <p>Key Status: <span className="text-status-online">✓ Generated</span></p>
                )}
                {isSecret && (
                  <p>Mode: <span className="text-red-400">PARANOID (Self-destruct)</span></p>
                )}
              </div>
            </div>
            <button onClick={() => setShowInfo(false)} className="text-text-muted hover:text-text-primary text-lg leading-none">×</button>
          </div>
        </div>
      )}
    </>
  )
}
