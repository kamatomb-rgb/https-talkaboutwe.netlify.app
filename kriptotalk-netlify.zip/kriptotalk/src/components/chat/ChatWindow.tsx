'use client'

import { useEffect, useRef, useCallback } from 'react'
import { useChatStore } from '@/lib/store/chatStore'
import { ChatHeader } from './ChatHeader'
import { MessageBubble } from './MessageBubble'
import { MessageInput } from './MessageInput'
import { TypingIndicator } from './TypingIndicator'
import { Lock } from 'lucide-react'

export function ChatWindow() {
  const { activeChat, activeChatData, messages, currentUser, typingIndicators, markAsRead } = useChatStore()
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  const chatMessages = activeChat ? (messages[activeChat] || []) : []
  const typingUsers = activeChat ? (typingIndicators[activeChat] || []) : []

  // Auto-scroll to bottom on new messages
  const scrollToBottom = useCallback((smooth = true) => {
    messagesEndRef.current?.scrollIntoView({ behavior: smooth ? 'smooth' : 'instant' })
  }, [])

  useEffect(() => {
    scrollToBottom(false)
  }, [activeChat])

  useEffect(() => {
    scrollToBottom(true)
  }, [chatMessages.length, typingUsers.length])

  // Mark as read when viewing
  useEffect(() => {
    if (activeChat) markAsRead(activeChat)
  }, [activeChat, chatMessages.length])

  if (!activeChat || !activeChatData) return null

  return (
    <div className="flex flex-col h-full bg-bg-primary">
      {/* Header */}
      <ChatHeader chat={activeChatData} currentUserId={currentUser?.id || ''} />

      {/* Messages area */}
      <div
        ref={containerRef}
        className="flex-1 overflow-y-auto px-4 py-4 space-y-1"
        style={{
          backgroundImage: `
            radial-gradient(circle at 20% 50%, rgba(0,212,255,0.02) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(123,47,255,0.02) 0%, transparent 50%)
          `,
        }}
      >
        {/* Encryption notice at top */}
        <div className="flex justify-center mb-4">
          <div className="flex items-center gap-2 bg-bg-card/80 border border-border-primary rounded-full px-4 py-2 text-xs text-text-muted font-mono">
            <Lock className="w-3 h-3 text-accent-primary" />
            <span>
              {activeChatData.type === 'secret'
                ? `🔴 Secret Chat · Self-destruct: ${activeChatData.secretChatConfig?.selfDestructLabel}`
                : 'Pesan dienkripsi end-to-end dengan ECDH-P521 + AES-256-GCM'
              }
            </span>
          </div>
        </div>

        {/* Messages */}
        {chatMessages.map((msg, index) => {
          const prevMsg = chatMessages[index - 1]
          const nextMsg = chatMessages[index + 1]
          const isMine = msg.senderId === currentUser?.id
          const isSystem = msg.senderId === 'system'

          // Group consecutive messages from same sender
          const isSameAsPrev = prevMsg?.senderId === msg.senderId
          const isSameAsNext = nextMsg?.senderId === msg.senderId

          if (isSystem) {
            return (
              <div key={msg.id} className="flex justify-center my-2">
                <div className="bg-bg-card border border-border-secondary rounded-full px-4 py-1.5 text-xs text-text-secondary text-center max-w-xs">
                  {msg.content}
                </div>
              </div>
            )
          }

          const sender = activeChatData.participantDetails?.find(p => p.id === msg.senderId)

          return (
            <MessageBubble
              key={msg.id}
              message={msg}
              isMine={isMine}
              sender={sender}
              chatId={activeChat}
              showAvatar={!isMine && !isSameAsNext}
              showName={!isMine && !isSameAsPrev && (activeChatData.type === 'group')}
              isLast={!isSameAsNext}
              allMessages={chatMessages}
            />
          )
        })}

        {/* Typing indicator */}
        {typingUsers.length > 0 && (
          <TypingIndicator
            typingUserIds={typingUsers}
            participants={activeChatData.participantDetails || []}
            currentUserId={currentUser?.id || ''}
          />
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Message input */}
      <MessageInput chatId={activeChat} chatType={activeChatData.type} />
    </div>
  )
}
