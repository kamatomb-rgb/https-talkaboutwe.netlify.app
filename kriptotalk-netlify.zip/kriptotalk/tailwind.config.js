/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['var(--font-inter)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      colors: {
        // KriptoTalk dark theme palette
        bg: {
          primary: '#0a0a0f',
          secondary: '#0f0f1a',
          tertiary: '#141428',
          card: '#1a1a2e',
          hover: '#1f1f35',
          input: '#16213e',
        },
        accent: {
          primary: '#00d4ff',
          secondary: '#7b2fff',
          glow: '#00d4ff33',
          purple: '#9d4edd',
          cyan: '#00b4d8',
        },
        text: {
          primary: '#e8e8f0',
          secondary: '#8888aa',
          muted: '#555570',
          accent: '#00d4ff',
        },
        border: {
          primary: '#2a2a45',
          secondary: '#1f1f38',
          glow: '#00d4ff44',
        },
        bubble: {
          sent: '#0d3464',
          received: '#1a1a35',
          sentBorder: '#1a4a8a',
          receivedBorder: '#2a2a4a',
        },
        status: {
          online: '#00e676',
          away: '#ffd54f',
          offline: '#455a64',
          encrypted: '#00d4ff',
        }
      },
      boxShadow: {
        'glow-cyan': '0 0 20px #00d4ff33, 0 0 40px #00d4ff11',
        'glow-purple': '0 0 20px #7b2fff33, 0 0 40px #7b2fff11',
        'card': '0 4px 24px rgba(0,0,0,0.4)',
        'bubble': '0 2px 8px rgba(0,0,0,0.3)',
      },
      animation: {
        'fade-in': 'fadeIn 0.2s ease-out',
        'slide-up': 'slideUp 0.3s ease-out',
        'slide-in-right': 'slideInRight 0.25s ease-out',
        'slide-in-left': 'slideInLeft 0.25s ease-out',
        'pulse-glow': 'pulseGlow 2s infinite',
        'typing': 'typing 1.4s infinite',
        'shimmer': 'shimmer 2s infinite',
        'lock-spin': 'lockSpin 0.5s ease-out',
      },
      keyframes: {
        fadeIn: { from: { opacity: 0 }, to: { opacity: 1 } },
        slideUp: { from: { transform: 'translateY(10px)', opacity: 0 }, to: { transform: 'translateY(0)', opacity: 1 } },
        slideInRight: { from: { transform: 'translateX(20px)', opacity: 0 }, to: { transform: 'translateX(0)', opacity: 1 } },
        slideInLeft: { from: { transform: 'translateX(-20px)', opacity: 0 }, to: { transform: 'translateX(0)', opacity: 1 } },
        pulseGlow: { '0%,100%': { boxShadow: '0 0 10px #00d4ff33' }, '50%': { boxShadow: '0 0 30px #00d4ff66, 0 0 60px #00d4ff22' } },
        typing: { '0%,80%,100%': { transform: 'scale(0.8)', opacity: 0.5 }, '40%': { transform: 'scale(1.2)', opacity: 1 } },
        shimmer: { from: { backgroundPosition: '-200% 0' }, to: { backgroundPosition: '200% 0' } },
        lockSpin: { from: { transform: 'rotate(-180deg) scale(0)' }, to: { transform: 'rotate(0) scale(1)' } },
      },
      backdropBlur: { xs: '2px' },
    },
  },
  plugins: [],
}
