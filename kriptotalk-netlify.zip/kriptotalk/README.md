# 🔐 KriptoTalk — Military-Grade Encrypted Messenger

> **Lebih aman dari Telegram.** KriptoTalk menggunakan ECDH P-521 + HKDF-SHA512 + AES-256-GCM + HMAC-SHA512 — cipher suite yang jauh melampaui MTProto 2.0 milik Telegram.

![KriptoTalk Banner](https://via.placeholder.com/800x200/0a0a0f/00d4ff?text=KriptoTalk+%E2%80%94+ECDH-P521+%2B+AES-256-GCM)

---

## 🛡️ Perbandingan Keamanan

| Fitur | Telegram MTProto 2.0 | **KriptoTalk** |
|-------|---------------------|----------------|
| Key Exchange | RSA-2048 | **ECDH P-521** |
| Symmetric Cipher | AES-256-IGE | **AES-256-GCM** |
| Key Derivation | SHA-256 | **HKDF-SHA512** |
| Message Auth | SHA-256 MAC | **GCM Auth + HMAC-SHA512** |
| Forward Secrecy | Secret Chats only | **Setiap pesan** |
| RSA Equivalent | 2,048-bit | **~15,360-bit** |
| Zero-Knowledge | Partial | **Full (server = ciphertext only)** |

---

## 🚀 Cara Menjalankan

### 1. Prerequisites

```bash
node --version  # v18 atau lebih baru
npm --version   # v9 atau lebih baru
```

### 2. Clone & Install

```bash
git clone https://github.com/yourusername/kriptotalk.git
cd kriptotalk
npm install
```

### 3. Setup Google OAuth

#### A. Buat Google Cloud Project
1. Buka [Google Cloud Console](https://console.cloud.google.com/)
2. Buat project baru atau pilih yang sudah ada
3. Aktifkan **Google+ API** atau **Google Identity Services**

#### B. Buat OAuth 2.0 Credentials
1. Ke **APIs & Services → Credentials**
2. Klik **Create Credentials → OAuth client ID**
3. Pilih **Web application**
4. Tambahkan **Authorized redirect URIs**:
   ```
   http://localhost:3000/api/auth/callback/google
   ```
5. Salin **Client ID** dan **Client Secret**

#### C. OAuth Consent Screen
1. Ke **OAuth consent screen**
2. Pilih **External**
3. Isi nama app: `KriptoTalk`
4. Tambahkan email kamu sebagai **Test user**

### 4. Environment Variables

```bash
cp .env.example .env.local
```

Edit `.env.local`:

```env
# Google OAuth (Client ID sudah diisi)
GOOGLE_CLIENT_ID=111427949829-aeu3irpt0mq277kk0g7v3lhdaivbfnrk.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-xxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Generate dengan: openssl rand -base64 32
AUTH_SECRET=your_super_secret_key_minimum_32_characters_here

NEXTAUTH_URL=http://localhost:3000
```

### 5. Jalankan

```bash
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000) 🎉

---

## 🏗️ Struktur Project

```
kriptotalk/
├── src/
│   ├── app/
│   │   ├── layout.tsx          # Root layout + fonts
│   │   ├── page.tsx            # Redirect ke /chat atau /login
│   │   ├── globals.css         # Global styles + animations
│   │   ├── login/
│   │   │   └── page.tsx        # Halaman login Google OAuth
│   │   ├── chat/
│   │   │   ├── layout.tsx      # Auth check + SessionProvider
│   │   │   └── page.tsx        # Main chat app
│   │   └── api/
│   │       └── auth/
│   │           └── [...nextauth]/
│   │               └── route.ts  # NextAuth handler
│   ├── components/
│   │   └── chat/
│   │       ├── Sidebar.tsx       # Daftar chat + search + user menu
│   │       ├── ChatListItem.tsx  # Item di daftar chat
│   │       ├── ChatWindow.tsx    # Area chat utama
│   │       ├── ChatHeader.tsx    # Header chat + info enkripsi
│   │       ├── MessageBubble.tsx # Bubble pesan + reactions + self-destruct
│   │       ├── MessageInput.tsx  # Input teks + emoji + voice
│   │       ├── TypingIndicator.tsx # Indikator sedang mengetik
│   │       ├── WelcomeScreen.tsx # Layar sambutan
│   │       └── NewChatModal.tsx  # Modal buat chat baru
│   ├── lib/
│   │   ├── crypto/
│   │   │   └── encryption.ts   # 🔑 Core E2E encryption engine
│   │   ├── store/
│   │   │   └── chatStore.ts    # Zustand global state
│   │   └── utils.ts            # Helper functions
│   ├── types/
│   │   ├── index.ts            # TypeScript type definitions
│   │   └── next-auth.d.ts      # NextAuth type augmentation
│   ├── auth.ts                 # NextAuth v5 config
│   └── middleware.ts           # Route protection
├── tailwind.config.js
├── next.config.mjs
├── tsconfig.json
└── .env.example
```

---

## 🔐 Arsitektur Enkripsi

### Protokol Per-Pesan (Zero Forward-Secrecy Leakage)

```
KIRIM PESAN:
─────────────────────────────────────────────────────────
1. Generate ephemeral ECDH P-521 key pair (per pesan!)
   → ephemeral_pub, ephemeral_priv

2. ECDH key agreement:
   shared_secret = ECDH(ephemeral_priv, recipient_pub)
   → 521 bits of shared entropy

3. Generate random salt (256-bit):
   salt = crypto.getRandomValues(32 bytes)

4. Key derivation via HKDF-SHA512:
   enc_key = HKDF(shared_secret, salt, "kriptotalk-enc")
   mac_key = HKDF(shared_secret, salt, "kriptotalk-mac")
   → Separate keys = domain separation

5. AES-256-GCM encryption:
   iv = crypto.getRandomValues(12 bytes)  // 96-bit IV
   ciphertext = AES-GCM-256(enc_key, iv, plaintext)
   // GCM auth tag = 128-bit built-in MAC

6. HMAC-SHA512 (additional authentication):
   hmac = HMAC-SHA512(mac_key, ciphertext || iv || ephemeral_pub)

7. Transmitted to server (only ciphertext, never plaintext):
   {ciphertext, iv, ephemeral_pub, salt, hmac, version: 2}
─────────────────────────────────────────────────────────

TERIMA PESAN:
─────────────────────────────────────────────────────────
1. ECDH key agreement (reverse):
   shared_secret = ECDH(my_priv, ephemeral_pub)
   // Same shared_secret due to ECDH symmetry

2. Re-derive same keys via HKDF

3. Verify HMAC-SHA512 FIRST (fail-fast if tampered)

4. Decrypt with AES-256-GCM
   // Also verifies GCM auth tag

5. Return plaintext (never stored on server)
─────────────────────────────────────────────────────────
```

### Security Properties

| Property | Status |
|----------|--------|
| **Confidentiality** | ✅ AES-256-GCM |
| **Integrity** | ✅ GCM Auth Tag + HMAC-SHA512 |
| **Authentication** | ✅ ECDH identity keys |
| **Forward Secrecy** | ✅ Ephemeral keys per message |
| **Replay Protection** | ✅ Unique IV + salt per message |
| **Tamper Detection** | ✅ Double MAC (GCM + HMAC) |
| **Zero-Knowledge Server** | ✅ Server = ciphertext only |
| **Key Fingerprint** | ✅ SHA-512 fingerprint display |

---

## 🎮 Fitur Demo

### Chat tersedia saat demo:
- **Aria Santoso** — Online, private chat
- **Budi Raharja** — Online, secret chat (self-destruct 5 menit)
- **Tim DevSecOps** — Group chat (4 anggota)
- **Citra Dewi** — Away, private chat

### Yang bisa kamu coba:
1. 💬 Kirim pesan → lihat enkripsi real-time di console
2. ❤️ Hover pesan → tambahkan reaction
3. 🔴 Buka Secret Chat → lihat countdown self-destruct
4. ➕ Buat chat baru → Private/Group/Secret
5. 📱 Resize ke mobile → sidebar collapse otomatis
6. 🔐 Klik info icon di header → lihat detail enkripsi

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 15 (App Router) |
| Language | TypeScript |
| Styling | Tailwind CSS |
| State | Zustand v5 |
| Auth | NextAuth v5 + Google OAuth 2.0 |
| Encryption | Web Crypto API (SubtleCrypto) |
| Animation | CSS Animations + Keyframes |
| Icons | Lucide React |
| Images | Next.js Image + DiceBear Avatars |

---

## 📦 Production Deployment

```bash
# Build
npm run build

# Set environment variables di hosting:
# - GOOGLE_CLIENT_ID
# - GOOGLE_CLIENT_SECRET  
# - AUTH_SECRET
# - NEXTAUTH_URL=https://yourdomain.com

# Tambahkan ke Google Console:
# Authorized redirect URIs: https://yourdomain.com/api/auth/callback/google

npm start
```

---

## 🔑 Generate AUTH_SECRET

```bash
openssl rand -base64 32
# atau
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

---

## ⚠️ Catatan Keamanan

1. **Private keys TIDAK pernah dikirim ke server** — hanya disimpan di memory client
2. **Server hanya menyimpan ciphertext** — tidak bisa membaca isi pesan
3. **Demo ini menggunakan in-memory storage** — untuk production, gunakan database terenkripsi
4. **Untuk production**: implement proper key exchange protocol dengan server sebagai relay
5. **Secret Chat**: pesan dihapus dari memory setelah timer habis

---

## 📄 License

MIT License — Free to use and modify.

---

<div align="center">
  <strong>🔐 KriptoTalk — Because Privacy is a Right, Not a Feature</strong>
</div>
